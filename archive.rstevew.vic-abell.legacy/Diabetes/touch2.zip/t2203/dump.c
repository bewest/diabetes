/*
 * dump.c - dump the meter's memory
 *
 * V. Abell
 */

/*
 * Copyright 1993, 1994, 1995, 1996 Victor A. Abell, Lafayette, Indiana 47906.
 * All rights reserved.
 *
 * Written by Victor A. Abell.
 *
 * Permission is granted to anyone to use this software for any purpose on
 * any computer system, and to alter it and redistribute it freely, subject
 * to the following restrictions:
 *
 * 1. Victor A. Abell is not responsible for any consequences of the use of
 * this software.
 *
 * 2. The origin of this software must not be misrepresented, either by
 *    explicit claim or by omission.  Credit to Victor A. Abell must
 *    appear in documentation and sources.
 *
 * 3. Altered versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 *
 * 4. This notice may not be removed or altered.
 */

#if	!defined(lint)

# if	defined(_BCC)
#pragma warn -use
# endif
static char copyright[] =
"@(#) Copyright 1993, 1994, 1995, 1996 Victor A. Abell.\nAll rights reserved.\n";
#endif

#include "touch2.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#define	RDYCOL	31			/* ready message column */
#define	SMROW	12			/* status message row */

char CksumErrMsg[64];			/* checksum error message */
int DumpHs = 0;				/* dump header status */
int DumpLc = 0;				/* number of dump lines */
char DumpfnQ[DUMPFNL];			/* QuattroPro dump file name */
char DumpfnR[DUMPFNL];			/* raw dump file name */
FILE *Dumpfs = NULL;			/* write dump file stream */
char DumpLine[DUMPLL+1];		/* dump line */
char *DumpLp[DUMPNL];			/* dump line pointers */
char DumpMtrCmd[4];			/* dump meter command -- DMI or DMP */
enum mtrtype DumpMtrTy = MTY_UNKNOWN;	/* dump type */
char *EvtBuf[] = {
	NULL,				/* title for event filter '1' */
	NULL,				/* title for event filter '2' */
	NULL,				/* title for event filter '3' */
	NULL,				/* title for event filter '4' */
	NULL,				/* title for event filter '5' */
	NULL,				/* title for event filter '6' */
	NULL,				/* title for event filter '7' */
	NULL,				/* title for event filter '8' */
	NULL,				/* title for event filter '9' */
	NULL,				/* title for event filter '10' */
	NULL,				/* title for event filter '11' */
	NULL,				/* title for event filter '12' */
	NULL,				/* title for event filter '13' */
	NULL,				/* title for event filter '14' */
	NULL				/* title for event filter '15' */
};

char Graphfn[DUMPFNL];			/* graph file name */
FILE *Graphfs = NULL;			/* graph file stream */
unsigned char IgnEvt[] =		/* events to ignore */
	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
unsigned char IgnEvtOrig[] =		/* original list of events to ignore */
	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
FILE *Rdumpfs = NULL;			/* read dump file stream */
short Rtype;				/* dump line reading type */
short RtypeB4Err;			/* reading type before meter error
					 * was detected */
short RtypeSave;			/* saved dump line reading type */
short SupTtlIO = 0;			/* suppress title line I/O to and
					 * from the dump file */


static char *DumpRdyMsg = "Waiting on meter";

struct menu DumpRdy[] = {
	{ 12, RDYCOL, NULL },
	{  0,  0, NULL },
};

struct menu DumpSt[] = {
	{ 12, 27, "Waiting for meter to start dump" },
	{  0,  0, NULL },
};

#define	TYPEBUFL	64
char CheckDump[TYPEBUFL];
char DumpFile[TYPEBUFL];
char DumpScreen[TYPEBUFL];
char EraseBuf[TYPEBUFL];
char FormatBuf[TYPEBUFL];
char GraphBuf[TYPEBUFL];
char GraphTtl[GTTLLNL+2+1];
char RangeTtl[TYPEBUFL];
char ReadBuf[TYPEBUFL];
char RevBuf[TYPEBUFL];
char SkipAftBuf[TYPEBUFL];
char SkipUntBuf[TYPEBUFL];
char SupTtlBuf[TYPEBUFL];
char EvtPromptBuf[TYPEBUFL];

struct menu DumpType[] = {
	{  6, 10, CheckDump },
	{  7, 10, EraseBuf },
	{  8, 10, DumpFile },
	{  9, 10, GraphBuf },
	{ 10, 10, SupTtlBuf },
	{ 11, 10, FormatBuf },
	{ 12, 10, ReadBuf },
	{ 13, 10, DumpScreen },
	{ 14, 10, "T - change graph Title from:" },
	{ 15, 12,  GraphTtl },
	{ 16, 10, RevBuf },
	{ 17, 10, "X - eXit" },
#define	DTIROW	19
	{  0,  0, NULL },
};

struct menu GraphType[] = {
	{  6,  8, SkipAftBuf },
	{  7,  8, "D - Disable event, group, ignore, range, and skip filters" },
	{  8,  8, EvtPromptBuf },
	{  9,  8, "F - write graph to File" },
#define GRPROW	10
#define GRPCOL	 8
#define	IGNROW	11
#define	IGNCOL	 8
	{ 12,  8, "R - select records to graph by time Range" },
	{ 13, 10, RangeTtl },
	{ 14,  8, "S - draw graph on Screen" },
	{ 15,  8, "T - change graph Title from:" },
	{ 16, 10, GraphTtl },
	{ 17,  8, SkipUntBuf },
	{ 18,  8, "X - eXit" },
	{  0,  0, NULL },
};

static int CheckCksum(int len, int x);
static void DispDumpLns(void);
static void EraseDump(void);
static int GetTrueFmts(void);
static int ReFmtDate(char *nd, char *dl);
static int ReFmtTime(char *nt, char *dl);
static int ReFmtUnits(char *nt, char *dl);
static int ReplaceDL(int x, char *nd);

#if	defined(UNIX)
static int GetDispLn(char *s, int n);
#else
static int GetDispLn(char *s, short n);
#endif

static int CheckFileNm(char *fn);
static int GetDumpType(char *ty);
static void RcvErr(int err);
static void ReadDump(void);
static int StoreDumpLn(void);
static void TrimSpaces(char *s);
static void WarnCantOpen(char *f);

#if	defined(UNIX)
static int WarnCksum(int f, int x);
#else
static int WarnCksum(short f, int x);
#endif

static int WarnDumpHdr(void);
static void WarnDumpLen(void);
static int WarnExist(char *d, struct stat *s);
static void WrDumpF(void);


/*
 * CheckCksum() - check checksum
 */


static int
CheckCksum(len, x)
	int len;			/* length of line in DumpLine */
	int x;				/* index if line in DumpLp[] */
{
	char cksum[5], *lp;
	short i;
	unsigned int sum;

	if (!Cksum)
		return(0);
	if (len < 5) {
		(void) strcpy(CksumErrMsg, "Record is too short.");
		return(1);
	}
/*
 * A leading 'I' or 'P' has been stripped from all dump header records,
 * and a leading "I " or "P " has been stripped from dump file records.
 * They need to be considered in computing the checksum.
 */
	lp = DumpLp[x];
	if (x == 0)
		sum = (unsigned int) DumpMtrCmd[2];
	else {
		if (lp[0] == DumpMtrCmd[2])
			sum = 0;
		else 
			sum = (unsigned int) DumpMtrCmd[2] + (unsigned int) ' ';
	}
	for (i = 0; i < (len - 5); i++)
		sum += (unsigned int)lp[i];
	(void) sprintf(cksum, "%04x", sum);
	if (strcmpi(lp + len - 4, cksum) == 0)
		return(0);
	for (i = 0; cksum[i]; i++) {
		if (isalpha(cksum[i]) && islower(cksum[i]))
			cksum[i] = toupper(cksum[i]);
	}
	(void) sprintf(CksumErrMsg, "Computed %s; read %s.",
		cksum, lp + len - 4);
	return(1);
}


/*
 * CheckESC() - check for ESC
 */

int
CheckESC()
{
	int ch;

	if (kbhit()) {
		if ((ch = getch()) == 0)
			ch = getch();
		if (ch == ESC)
			return(1);
		putch(BELL);
	}
	return(0);
}


/*
 * CheckFilNm() - check file name
 */

static int
CheckFileNm(fn)
	char *fn;			/* file name to check */
{
	char *cp = NULL;
	short err = 0;
	short fnl;
	short lc, p, rc;
	char *mp, msg[80];

/*
 * Skip leading alpha, followed by a colon -- i.e., a drive specification.
 * Skip leading "./", ".\", "../", and "..\".
 */
	fnl = strlen(fn);
	if (fnl > 1) {
		if ((isalpha(*fn) && fn[1] == ':')
		||   strncmp(fn, "./", 2) == 0
		||   strncmp(fn, ".\\", 2) == 0)
			cp = fn + 2;
	}
	if (cp == NULL && fnl > 2) {
		if (strncmp(fn, "../", 3) == 0
		||  strncmp(fn, "..\\", 3) == 0)
			cp = fn + 3;
	}
	if (cp == NULL)
		cp = fn;
/*
 * Check the file path components -- i.e., those between / and \.
 *
 * The left part (the name) may have no more than 8 characters.
 * The right part (the extension) may have no more than 3 characters.
 * There may be one period, separating the name and extension.
 * The characters must be alphanumeric or special characters from the set:
 *
 *	_ ^ $ ~ ! # % & - { } @ ` ' ( )
 */
	(void) strcpy(msg, "has ");
	mp = &msg[strlen(msg)];
	while (err == 0 && *cp) {
	    if (*cp == '/' || *cp == '\\') {
	    	cp++;
		continue;
	    }
	    lc = p = rc = 0;
	    while (*cp) {
		switch (*cp) {
	    /*
	     * These are the legal special characters.
	     */
		case '_':
		case '^':
		case '$':
		case '~':
		case '!':
		case '#':
		case '%':
		case '&':
		case '-':
		case '{':
		case '}':
		case '@':
		case '`':
		case '\'':
		case ')':
		case '(':
		    break;
	    /*
	     * The / and \ end a component.
	     */
		case '/':
		case '\\':
		    err = -1;
		    break;
	    /*
	     * The period separates the name and extension.
	     */
		case '.':
		    if (p) {
			(void) strcpy(mp, "more than one period.");
			err = 1;
		    } else if (lc == 0) {
			(void) strcpy(mp,
			    "nothing to the left of the period.");
			err = 1;
			break;
		    } else
			p = 1;
		    break;
	    /*
	     * Letters (either case) and numbers are legal.
	     */
		default:
		    if (isalnum(*cp))
			break;
		    (void) strcpy(mp, "an illegal character.");
		    err = 1;
		}
	    /*
	     * Stop on error or end of component.  Skip a period.
	     */
		if (err)
		    break;
		if (*cp++ == '.')
		    continue;
	    /*
	     * The name may have 8 characters; the extension, 3.
	     */
		if ( ! p) {
		    if (lc > 7) {
			(void) strcpy(mp,
			    "more than 8 characters in the name part.");
			err = 1;
		    } else
			lc++;
		} else {
		    if (rc > 2) {
			(void) strcpy(mp,
			    "more than 3 characters in the extension.");
			err = 1;
		    } else
			rc++;
		}
	    }
	/*
	 * Continue after the end of a component; stop on an error.
	 */
	    if (err == -1) {
		err = 0;
		continue;
	    }
	    if (err)
		break;
	}
/*
 * Return if no error; warn if there was one.
 */
	if (err == 0)
	    return(0);
	(void) WarnMsg(11, (short)((Vc.screenwidth - fnl)/2 + 1), fn,
	    13, (short)((Vc.screenwidth - strlen(msg))/2 + 1), msg, 0);
	return(1);
}


/*
 * DumpMtr() - dump the meter's memory
 */

void
DumpMtr()
{
	int i;
	char dt, msg[32];

	while (GetDumpType(&dt)) {
	    if ( ! DumpLc && dt != 'r') {
		for (;;) {
		    if (Debug)
			CommDisp(NULL);
		    if (WaitRdy(0) == 0) {
			(void) CloseDump();
			break;
		    }
		/*
		 * WaitRdy(0) determines the meter type.
		 */
		    if (MtrTy == MTY_PROFILE) {
			DumpMtrTy = MTY_PROFILE;
			(void) strcpy(DumpMtrCmd, "DMI");
		    }  else {
			DumpMtrTy = MtrTy;
			(void) strcpy(DumpMtrCmd, "DMP");
		    }
		    if ( ! Debug)
			DispMenu(DumpSt, NULL);
		    if (WaitCmd(DumpMtrCmd, DumpMtrCmd[2]) == 0) {
			(void) strcpy(DumpLine, "Dump command failed.");
			if ((char)WarnMsg(12,
			    (short)(((Vc.screenwidth - strlen(DumpLine))/2)+1),
				DumpLine, 0, 0, NULL, 1)
			== ESC) {
				(void) CloseDump();
				break;
			}
			continue;
		    }
		    if ( ! Debug)
			clrscr();
		    PromptMsg("Press ESC to exit.");
		    (void) GetDataLn(DumpLine, DUMPLL);
		    if (StoreDumpLn()) {
			(void) CloseDump();
			(void) EraseDump();
			break;
		    }
		    if ( ! ParseHdr()) {
			if ((char)WarnDumpHdr() == ESC) {
				(void) CloseDump();
				(void) EraseDump();
				break;
			}
		    }
		    gotoxy(RDYCOL, SMROW);
		    (void) cputs("Header record read.");
		    for (i = 0;;) {
			if (CheckESC()) {
				(void) CloseDump();
				(void) EraseDump();
				break;
			}
			(void) GetDataLn(DumpLine, DUMPLL);
			if (DumpLine[0] != DumpMtrCmd[2])
				break;
			if (StoreDumpLn()) {
				(void) CloseDump();
				(void) EraseDump();
				break;
			}
			if (i == 0) {
				ClearRow(SMROW, RDYCOL);
				(void) sprintf(msg,
					"Record %3d read.", DumpLc - 1);
				gotoxy(RDYCOL, SMROW);
				i = 1;
			} else {
				gotoxy(RDYCOL+7, SMROW);
				(void) sprintf(msg, "%3d", DumpLc - 1);
			}
			cputs(msg);
		    }
		    if (Ndump+1 != DumpLc)
			WarnDumpLen();
		    if (Cksum) {
			for (i = 0; i < DumpLc; i++) {
				if (CheckCksum(strlen(DumpLp[i]), i)) {
					if ((char)WarnCksum(1, i) == ESC) {
						(void) CloseDump();
						(void) EraseDump();
						break;
					}
				}
			}
		    }
		/*
		 * If this is a Profile(TM) dump, get the true date, time,
		 * and units of measure formats.  Propagate them to the
		 * stored dump header and data records.
		 */
		    if (MtrTy == MTY_PROFILE) {
			if (GetTrueFmts()) {
			    (void) CloseDump();
			    (void) EraseDump();
			}
		    }
		    break;
	        }
		if ( ! DumpLc || (dt != 'f' && dt != 's'))
		    continue;
	    }
	    switch (dt) {
		case 'f':
			WrDumpF();
			break;
		case 'g':
		case 'G':
			DrawGraph((dt == 'g') ? 0 : 1);
			break;
		case 'r':
			ReadDump();
			break;
		case 's':
			DispDumpLns();
	    }
	}
}


/*
 * DispDumpLns() - display dump lines
 */

static void
DispDumpLns(void)
{
	char *bf, bot[80], *cp;
	int cpl, i, j, k, lps;

	if (DumpLc == 0)
		return;
	cpl = Vc.screenwidth;
	lps = Vc.screenheight;
	if ((bf = (char *)malloc((size_t)(cpl + 1))) == NULL) {
		clrscr();
		gotoxy(20, 12);
		(void) cputs("DispDump: no temporary line space");
		return;
	}

	i = 0;
	for (;;) {

	/*
	 * Display a screenload.
	 */
		clrscr();
		for (j = 1; j < lps && (i+j-1) < DumpLc;  j++) {
			for (cp = DumpLp[i+j-1], k = 0; k < cpl; cp++) {
				if (*cp == '"')
					continue;
				if (*cp == '\0')
					break;
				bf[k++] = *cp;
			}
			bf[k] = '\0';
			gotoxy(1, j);
			(void) cputs(bf);
		}
		(void) sprintf(bot,
		  "(%d of %d) Press ESC or X to exit; Page Up/Down; Arrow Up/Down.",
		  i+1, DumpLc);
		PromptMsg(bot);
	/*
	 * Wait for a command.
	 */
		for (k = 1; k;) {
			switch((char)WaitAnyKey()) {
			case ESC:
			case 'x':
			case 'X':
				return;
			case PGDN:
				if ((i + lps - 1) < DumpLc) {
					i += lps - 1;
					k = 0;
				} else
					putch(BELL);
				break;
			case PGUP:
				if (i > 0) {
					i -= lps - 1;
					if (i < 0)
						i = 0;
					k = 0;
				} else
					putch(BELL);
				break;
			case UARW:
				if (i > 0) {
					i--;
					k = 0;
				} else
					putch(BELL);
				break;
			case DARW:
				if (i < (DumpLc - 1)) {
					i++;
					k = 0;
					break;
				}
				/* fall through */
			default:
				putch(BELL);
			}
		}
	}
} 


/*
 * EraseDump() -- erase dump
 */

static void
EraseDump(void)
{
	int i;

	for (i = 0; i < DumpLc; i++) {
		(void) free(DumpLp[i]);
		DumpLp[i] = NULL;
	}
	DumpLc = Ndump = 0;
}


/*
 * GetDataLn(s, n) - get meter data line
 */

int
GetDataLn(s, n)
	char *s;
	int n;
{
	char c;
	int err, i;

	for (i = 0;;) {
		if (CheckESC()) {
			s[0] = '\0';
			return(0);
		}
		AsynInp(&c, &err);
		if ( ! err && c) {
			if (Debug)
				CommDisp(&c);
			if (c == CR)
				break;
			if (c == LF)
				continue;
			if (i+1 >= n)
				break;
			s[i++] = c;
		} else if (err == 6)
			continue;
		else if (err) {
			RcvErr(err);
			return(0);
		}
	}
	s[i] = '\0';
	return(i);
}


/*
 * GetDumpType() - get dump type
 */

static int
GetDumpType(ty)
	char *ty;			/* type response */
{
	struct evtgrpe *eg;
	char fn[DUMPFNL];
	short i, j, m, m1;
	struct stat sbuf;
	char *t;

	Dumpfs = Graphfs = NULL;
	for (m = 0;;) {
		if ( ! m) {
		    (void) sprintf(FormatBuf,
			"Q - change dump format to %s from %s",
			Qp ? "raw" : "QuattroPro",
			Qp ? "QuattroPro" : "raw");
		    if (Qp)
			(void) sprintf(CheckDump,
		    	    "C - %sdump Check, error, and high readings",
			    Ckdump ? "" : "don't ");
		    else
			CheckDump[0] = '\0';
		    if (DumpLc) {
			i = DumpLc - DumpHs;
			t = (i == 1) ? "record" : "records";
			(void) sprintf(EraseBuf,
				"E - Erase %d %s from dump buffer", i, t);
			(void) sprintf(DumpFile,
				"F - dump %d %s to File", i, t);
			(void) sprintf(GraphBuf, "G - Graph %d %s", i, t);
			ReadBuf[0] = '\0';
			(void) sprintf(DumpScreen,
				"S - dump %d %s to Screen", i, t);
			if (i > 1)
			    (void) sprintf(RevBuf,
				"V - reVerse order of %d %s", i, t);
			    else
				RevBuf[0] = '\0';
		    } else {
			EraseBuf[0] = RevBuf[0] = '\0';
			(void) strcpy(DumpFile, "F - dump to File");
			(void) strcpy(GraphBuf, "G - Graph");
			(void) strcpy(ReadBuf, "R - Read from file");
			(void) strcpy(DumpScreen, "S - dump to Screen");
		    }
		    if (Gttl[0] != '\0') {
			if (ExpandTtl())
				(void) sprintf(GraphTtl, "Error: %s",
					TtlErrMsg);
			else
				(void) sprintf(GraphTtl, "\"%s\"", Exttl);
		    } else
			GraphTtl[0] = '\0';
		    (void) sprintf(SupTtlBuf,
			"L - read/write graph titLe from/to dump file: %s",
			SupTtlIO ? "no" : "yes");
		    DispMenu(DumpType, NULL);
		    m = 1;
		}
		switch((char)WaitAnyKey()) {
		case 'x':
		case 'X':
		case ESC:
			return(0);
		case 'c':
		case 'C':
			Ckdump = Ckdump ? 0 : 1;
			m = 0;
			break;
		case 'e':
		case 'E':
			if ( ! DumpLc)
				putch(BELL);
			else {
				(void) EraseDump();
				if (GttlOrig)
					(void) strcpy(Gttl, GttlOrig);
				else
					Gttl[0] = '\0';
				m = 0;
			}
			break;
		case 'f':
		case 'F':
			(void) strcpy(fn, Qp ? DumpfnQ : DumpfnR);
			if (GetInp(DTIROW, 5, "Name?", fn, fn, sizeof(fn)) == 0
			||  CheckFileNm(fn)) {
				m = 0;
				break;
			}
			if (stat(fn, &sbuf) == 0) {
				if (WarnExist(fn, &sbuf) == 0) {
					m = 0;
					break;
				}
			}
			if ((Dumpfs = fopen(fn, "w+t")) != NULL) {
				(void) strcpy(Qp ? DumpfnQ : DumpfnR, fn);
				*ty = 'f';
				return(1);
			}
			WarnCantOpen(fn);
			m = 0;
			break;
		case 'g':
		case 'G':
			for (m1 = 0; m1 == 0;) {
			    if (Gttl[0] != '\0') {
				if (ExpandTtl())
				    (void) sprintf(GraphTtl, "Error: %s",
					TtlErrMsg);
				else
				    (void) sprintf(GraphTtl, "\"%s\"", Exttl);
			    } else
				GraphTtl[0] = '\0';
			    if (RangeInUse > 0)
			    	(void) sprintf(RangeTtl, "\"%s\"",
					TmRange[RangeInUse - 1].tm);
			    else
				RangeTtl[0] = '\0';
			    if (SkipAft)
				(void) sprintf(SkipAftBuf,
				    "A - skip After \"%s\",\"%s\"",
				    SkipAftDt, SkipAftTm);
			    else
				(void) strcpy(SkipAftBuf,
				    "A - skip After date and time");
			    if (SkipUnt)
				(void) sprintf(SkipUntBuf,
				    "U - skip Until \"%s\",\"%s\"",
				    SkipUntDt, SkipUntTm);
			    else
				(void) strcpy(SkipUntBuf,
				    "U - skip Until date and time");
			    if (Eventfilt) {
			      if (MtrTy == MTY_PROFILE)
				(void) sprintf(EvtPromptBuf,
				  "E - graph only %s (%s) Events [%#x (%d)]",
				  EventCode[Eventfilt].nm,
				  EventCode[Eventfilt].ab,
				  Eventfilt, Eventfilt);
			      else
			        (void) sprintf(EvtPromptBuf,
				  "E - graph only %#x (%d) Events",
				  Eventfilt, Eventfilt);
			    } else
				(void) strcpy(EvtPromptBuf,
				    "E - define Event to graph");
			    DispMenu(GraphType, NULL);
			    gotoxy(GRPCOL, GRPROW);
			    if (EEvtGrp) {
				(void) cprintf("G - graph Group of events:");
				for (eg = EEvtGrp->grp; eg; eg = eg->next) {
				    cprintf(" %x", eg->grp);
				}
			    } else
				(void) cprintf("G - define Group of events");
			    gotoxy(IGNCOL, IGNROW);
			    cprintf("I - Ignore events:");
			    for (i = 1; i < 16; i++) {
			    	if (IgnEvt[i - 1] == 0)
				    continue;
				cprintf(" %x", i);
			    }
			    switch ((char)WaitAnyKey()) {
			    case 'x':
			    case 'X':
			    case ESC:
			        m1 = 1;
				Eventfilt = 0;
				EEvtGrp = (struct evtgrphd *)NULL;
				RangeInUse = SkipAft = SkipUnt = 0;
				if (GttlDumpf[0] != '\0')
					(void) strcpy(Gttl, GttlDumpf);
				else if (GttlOrig)
					(void) strcpy(Gttl, GttlOrig);
				for (i = 0; i < 15; i++)
					IgnEvt[i] = IgnEvtOrig[i];
				break;
			    case 'a':
			    case 'A':
				SelSkipAft();
				break;
			    case 'd':
			    case 'D':
				Eventfilt = 0;
				EEvtGrp = (struct evtgrphd *)NULL;
				for (i = 0; i < 16; i++)
					IgnEvt[i] = 0;
				RangeInUse = SkipAft = SkipUnt = 0;
				if (GttlDumpf[0] != '\0')
					(void) strcpy(Gttl, GttlDumpf);
				else if (GttlOrig)
					(void) strcpy(Gttl, GttlOrig);
				break;
			    case 'e':
			    case 'E':
				SelEvent();
				break;
			    case 'f':
			    case 'F':
				(void) strcpy(fn, Graphfn);
				if (GetInp(19, 5, "Name?", fn, fn, sizeof(fn))
				== 0)
					break;
				if (CheckFileNm(fn))
					break;
				if (stat(fn, &sbuf) == 0) {
					if (WarnExist(fn, &sbuf) == 0)
						break;
				}
				if ((Graphfs = fopen(fn, "w+t")) != NULL) {
					(void) strcpy(Graphfn, fn);
					DrawGraph(1);
					break;
				}
				WarnCantOpen(fn);
				break;
			    case 'g':
			    case 'G':
				SelEvtGrp();
				break;
			    case 'i':
			    case 'I':
				SelIgnEvt();
				break;
			    case 'r':
			    case 'R':
				SelTmRange();
				break;
			    case 's':
			    case 'S':
				DrawGraph(0);
				break;
			    case 't':
			    case 'T':
				if (GetInp(19, 7, "Title?", Gttl, GraphTtl,
				    GTTLLNL)
				!= 0)
				    (void) strcpy(Gttl, GraphTtl);
				else {
					if (GttlDumpf[0] != '\0')
						(void) strcpy(Gttl, GttlDumpf);
					else if (GttlOrig)
						(void) strcpy(Gttl, GttlOrig);
				}
				break;
			    case 'u':
			    case 'U':
				SelSkipUnt();
				break;
			    default:
				putch(BELL);
			    }
			}
			m = 0;
			break;
		case 'l':
		case 'L':
			SupTtlIO = SupTtlIO ? 0 : 1;
			m = 0;
			break;
		case 'q':
		case 'Q':
			Qp = (Qp == 1) ? 0 : 1;
			m = 0;
			break;
		case 'r':
		case 'R':
			(void) strcpy(fn, DumpfnR);
			if (GetInp(DTIROW, 5, "Name?", fn, fn, sizeof(fn)) == 0
			||  CheckFileNm(fn)) {
				m = 0;
				break;
			}
			if ((Rdumpfs = fopen(fn, "r+t")) != NULL) {
				(void) strcpy(DumpfnR, fn);
				*ty = 'r';
				return(1);
			}
			WarnCantOpen(fn);
			m = 0;
			break;
		case 's':
		case 'S':
			*ty = 's';
			return(1);
		case 't':
		case 'T':
			if (GetInp(DTIROW, 7, "Title?", Gttl, GraphTtl, GTTLLNL)
			!= 0)
				(void) strcpy(Gttl, GraphTtl);
			else {
				if (GttlDumpf[0] != '\0')
					(void) strcpy(Gttl, GttlDumpf);
				else if (GttlOrig)
					(void) strcpy(Gttl, GttlOrig);
			}
			m = 0;
			break;
		case 'v':
		case 'V':
			if ((i = DumpLc - DumpHs) < 2) {
			    if (i == 0)
			    	(void) strcpy(RevBuf,
				    "There are no dump records.");
			    else
				(void) strcpy(RevBuf,
				    "No need to reverse just 1 record.");
			    (void) WarnMsg(11,
				(short)((Vc.screenwidth-strlen(RevBuf))/2 + 1),
				RevBuf, 0, 0, NULL, 0);
			    m = 0;
			    break;
			}
			for (i = DumpHs, j = DumpLc - 1; i < j; i++, j--) {
			    t = DumpLp[j];
			    DumpLp[j] = DumpLp[i];
			    DumpLp[i] = t;
			}
			(void) sprintf(RevBuf,
			    "The order of %d dump records has been reversed.",
			    DumpLc - DumpHs);
			(void) WarnMsg(11,
			    (short)((Vc.screenwidth - strlen(RevBuf))/2 + 1),
			    RevBuf, 0, 0, NULL, 0);
			m = 0;
			break;
		default:
			putch(BELL);
		}
	}
}



/*
 * GetDispLn(s) - get meter display line
 */

static int
GetDispLn(s, n)
	char *s;			/* destination buffer */

#if	defined(UNIX)
	int n;				/* destination buffer length */
#else
	short n;			/* destination buffer length */
#endif

{
	char c;
	int err, i;

	for (i = 0;;) {
		if (CheckESC()) {
			s[0] = '\0';
			return(0);
		}
		AsynInp(&c, &err);
		if ( ! err && c) {
			if (Debug)
				CommDisp(&c);
			if (c == LF)
				continue;
			if (c == CR) {
				s[i] = '\0';
				break;
			}
			if (i < n - 1)
				s[i++] = c;
			else {
				s[i] = '\0';
				return(0);
			}
		} else if (err == 6)
			continue;
		else if (err) {
			RcvErr(err);
			return(0);
		}
	}
	return(1);
}


/*
 * GetTrueFmts() - get the true Profile meter formats for date, time, and
 *		   units of measure, and propagate them to the dump header
 *		   and dump records
 */

static int
GetTrueFmts()
{
	char *cp, dl[DUMPLL+1];
	int dc, err, i, pc, tc, uc, ut;
	char date[FIELDLN];
	char mdate[STATLL];
	char mtime[STATLL];
	char munits[STATLL];
	char time[FIELDLN];
	char units[FIELDLN];
/*
 * Get the current formats for date, time and units of measure.
 */
	DumpRdy[0].msg = "Getting field formats";
	(void) strcpy(mdate, Mdate);
	(void) strcpy(mtime, Mtime);
	(void) strcpy(munits, Munits);
	i = ReadAll();
	DumpRdy[0].msg = DumpRdyMsg;
	if (i == 0)
	    return(1);
/*
 * If the current dump formats match the inflexible ones of the DMI command,
 * nothing need be done.
 */
	dc = strcmp(mdate, Mdate);
	tc = strcmp(mtime, Mtime);
	uc = strcmp(munits, Munits);
	if (dc == 0 && tc == 0 && uc == 0)
	    return(0);
/*
 * Update the dump header line.
 */
	(void) sprintf(dl,
	    " %3d,\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"",
	    DumpLc - DumpHs, Mserial, Mlang, Mdate, Mtime, Munits, Mmin,
	    Mmax);
	if (ReplaceDL(0, dl))
	    return(1);
/*
 * Update the data lines.
 */
	for (err = 0, i = DumpHs; i < DumpLc; i++) {
	    if (ParseDumpLn(DumpLp[i], 0, 0) == 0) {
		(void) WarnMsg(10, 34, "Bad dump line:", 12,
		    (short)(((Vc.screenwidth - strlen(DumpLp[i]))/2)+1),
		    DumpLp[i], 2);
		err++;
	    }
	/*
	 * If the date format is different, reformat the date.
	 */
	    if (dc) {
		if (ReFmtDate(date, DumpLp[i])) {
		    err = 1;
		    continue;
		}
	    } else
		(void) strcpy(date, Date);
	/*
	 * If the time format is different, reformat the time.
	 */
	    if (tc) {
		if (ReFmtTime(time, DumpLp[i])) {
		    err = 1;
		    continue;
		}
	    } else
		(void) strcpy(time, Time);
	/*
	 * If the units format is different, reformat the units.
	 */
	    if (uc) {
		if (ReFmtUnits(units, DumpLp[i])) {
		    err = 1;
		    continue;
		}
	    } else
		(void) strcpy(units, Units);
	    (void) sprintf(dl, "\"%s\",\"%s\",\"%s\",\"%s\", %2d",
		Dow, date, time, units, Event);
	    if (ReplaceDL(i, dl))
		err = 1;
	}
	if (err)
	    return(1);
	return(0);
}


/*
 * InitDump() - initialize dump
 */

void
InitDump()
{
	(void) strcpy(DumpfnQ, DEFQDMPF);
	(void) strcpy(DumpfnR, DEFRDMPF);
	(void) strcpy(Graphfn, DEFGRAPHF);
	(void) strcpy(DumpMtrCmd, "DMP");
	DumpMtrTy = MTY_UNKNOWN;
	Gttl[0] = GttlDumpf[0] = '\0';
	DumpRdy[0].msg = DumpRdyMsg;
}


/*
 * Rcverr() - handle receive error
 */

static void
RcvErr(err)
	int err;
{
	switch (err) {
	case 7:
		(void) sprintf(DumpLine, "COM%d receive buffer overflow error",
			Port + 1);
		break;
	case 10:
		(void) sprintf(DumpLine,
			"COM%d receive port is not initialized.", Port + 1);
		break;
	default:
		(void) sprintf(DumpLine, "Unknown COM%d receive error: %d",
			Port + 1, err);
	}
	(void) WarnMsg(12,
		(short)(((Vc.screenwidth - strlen(DumpLine))/2) + 1),
		DumpLine,
		0, 0, NULL, 0);
}


/*
 * ReadDump() - read dump from file
 */

static void
ReadDump(void)
{
	char *cp, *rv;
	int i, len;
	short err = 0;

/*
 * Read, parse and store the dump title and header lines.
 *
 * Determine the meter type from the presence or absence of the "PROFILE:"
 * dump header line.
 */
	(void) strcpy(DumpMtrCmd, "DMP");
	GttlDumpf[0] = '\0';
	while ((rv = fgets(DumpLine, DUMPLL, Rdumpfs)) != NULL) {
		if ((cp = strrchr(DumpLine, '\n')) != NULL) {
			*cp = '\0';
			len = cp - DumpLine;
		} else {
			DumpLine[DUMPLL-1] = '\0';
			len = strlen(DumpLine);
		}
		if (strncmp(DumpLine, "TTL:", 4) == 0) {
			if ( ! SupTtlIO) {
				(void) strncpy(Gttl, &DumpLine[4], GTTLLNL);
				Gttl[GTTLLNL] = '\0';
				(void) strcpy(GttlDumpf, Gttl);
			}
			continue;
		}
		if (strcmp(DumpLine, "PROFILE:") == 0) {
			DumpMtrCmd[2] = 'I';
			DumpMtrTy = MtrTy = MTY_PROFILE;
			continue;
		}
		if (StoreDumpLn()) {
			(void) CloseDump();
			(void) EraseDump();
			return;
		}
		if (CheckCksum(len, 0)) {
			if ((char)WarnCksum(1, 0) == ESC) {
				(void) CloseDump();
				(void) EraseDump();
				return;
			}
		}
		break;
	}
	if (rv == NULL)
		DumpLine[0] = '\0';
	if (rv == NULL || ! ParseHdr()) {

	/*
	 * Handle bad dump header line.
	 */
		i = WarnDumpHdr();
		if (DumpLc)
			(void) EraseDump();
		if ((char)i == ESC) {
			(void) CloseDump();
			return;
		}
		err = 1;
	}
/*
 * If there was no "PROFILE:" dump header line, set the meter type to
 * One Touch II.
 */
	if (DumpMtrCmd[2] != 'I')
		DumpMtrTy = MtrTy = MTY_ONETOUCH2;
/*
 * Read and store the dump lines.
 */
	while (fgets(DumpLine, DUMPLL, Rdumpfs) != NULL) {
		if ((cp = strrchr(DumpLine, '\n')) != NULL) {
			*cp = '\0';
			len = cp - DumpLine;
		} else {
			DumpLine[DUMPLL-1] = '\0';
			len = strlen(DumpLine);
		}
		if (StoreDumpLn()) {
			err = 1;
			break;
		}
		if (CheckCksum(len, DumpLc - 1)) {
			if ((char)WarnCksum(1, DumpLc - 1) == ESC) {
				(void) CloseDump();
				(void) EraseDump();
				return;
			}
		}
	}
	(void) CloseDump();
	if (err == 0 && (Ndump+1 != DumpLc))
		WarnDumpLen();
}


/*
 * ReFmtDate() - reformat Profile date
 */

static int
ReFmtDate(nd, dl)
	char *nd;				/* new date */
	char *dl;				/* dump line */
{
	char *cp;
	int d[3], n[3], nx;
/*
 * Get the three previous date numbers.
 */
	d[0] = d[1] = d[2] = n[0] = n[1] = n[2] = 0;
	for (cp = Date, nx = 0; *cp; cp++) {
	    if (*cp == ' ')
		continue;
	    if (*cp == '/') {
		if (++nx > 2)
rfdate_err:
		{
		    (void) WarnMsg(12, 30, "Can't reformat date:", 14,
			(short)((Vc.screenwidth - strlen(dl))/2 + 1), dl, 2);
		    return(1);
		}
		continue;
	    }
	    if (*cp < '0' || *cp > '9')
		goto rfdate_err;
	    n[nx] = (n[nx] * 10) + (int)(*cp - '0');
	    d[nx]++;
	}
	if (nx != 2 || (d[0] < 1 || d[0] > 2) || (d[1] < 1 || d[1] > 2)
	||  (d[2] < 1 || d[2] > 2))
	    goto rfdate_err;
/*
 * Reverse the previous date format.
 */
	(void) sprintf(nd, "%2d/%02d/%02d", n[1], n[0], n[2]);
	return(0);
}


/*
 * ReFmtTime() - reformat Profile time
 */

static int
ReFmtTime(nt, dl)
	char *nt;				/* new time */
	char *dl;				/* dump line */
{
	char *cp, msg[128];
	int hr, mn, tm;
/*
 * Get the hour and minute.
 */
	cp = Time;
	if ((tm = CvtTm(&cp, msg)) < 0) {
	    (void) WarnMsg(12, 30, "Can't reformat time:", 14,
		(short)((Vc.screenwidth - strlen(dl))/2 + 1), dl, 2);
	    return(1);
	}
	hr = tm / 60;
	mn = tm % 60;
	if (strncmp(Mtime, "24:00", 5) == 0) {

	/*
	 * Convert from AM/PM to 24:00
	 */
	     (void) sprintf(nt, "%2d:%02d:00   ", hr, mn);
	     return(0);
	 }
/*
 * Convert from 24:00 to AM/PM
 */
	if (hr < 12) {
		(void) sprintf(nt, "%2d:%02d:00 AM", hr, mn);
		return(0);
	}
	(void) sprintf(nt, "%2d:%02d:00 PM", hr - 12, mn);
	return(0);
}


/*
 * ReFmtUnits() - reformat Profile Units
 */


static int
ReFmtUnits(nu, dl)
	char *nu;				/* new units */
	char *dl;				/* dump line */
{
	char *cp, *err;
	int nf;
/*
 * Define the new format, mmol/L or mg/dL.
 * Establish the meter error flag value.
 * Establish the mmol/L punctuation.
 */
	nf = strncmp(Munits, "MG/DL", 5);
	err = (Rtype == RDMTRERR) ? "?" : " ";
/*
 * Convert by the record type that was assigned before any meter error
 * code was sensed.
 */
	switch (RtypeB4Err) {
	case RDREG:
	    if (nf)
		(void) sprintf(nu, "MM%4.1f%s", (Rval / 18.0), err);
	    else
		(void) sprintf(nu, "  %3d%s", (int)(Rval * 18.0), err);
	    return(0);
	case RDBOLI:
	case RDCARB:
	case RDCKHI:
	case RDHIGH:
	case RDOTHI:
	    (void) strcpy(nu, Units);
	    return(0);
	case RDSTRIP:
	    if (nf)
		(void) sprintf(nu, "! %4.1f%s", (Rval / 18.0), err);
	    else
		(void) sprintf(nu, "! %3d%s", (int)(Rval * 18.0), err);
	    return(0);
	case RDSOL:
	    if (nf)
		(void) sprintf(nu, "C %4.1f%s", (Rval / 18.0), err);
	    else
		(void) sprintf(nu, "C %3d%s", (int)(Rval * 18.0), err);
	    return(0);
	}
	(void) WarnMsg(12, 30, "Can't reformat units:", 14,
	    (short)((Vc.screenwidth - strlen(dl))/2 + 1), dl, 2);
	return(1);
}


/*
 * ReplaceDL() - replace dump line
 */

static int
ReplaceDL(x, nd)
	int x;					/* DumpLp[] index */
	char *nd;				/* new dump line buffer */
{
	char *cp;
	short i;
	size_t len;
	unsigned int sum;
/*
 * Generate new checksum.
 */
	if (x == 0)
		sum = (unsigned int) DumpMtrCmd[2];
	else {
		if (*nd == DumpMtrCmd[2])
			sum = 0;
		else 
			sum = (unsigned int) DumpMtrCmd[2] + (unsigned int) ' ';
	}
	len = strlen(nd);
	for (i = 0; i < len; i++) {
	    sum += (unsigned int)nd[i];
	}
/*
 * Allocate space for the new dump record and copy it there.
 * Add its checksum.
 * Replace the old dump record with the new one.
 */
	if ((cp = (char *)malloc(len + 5 + 1)) == (char *)NULL) {
	    (void)WarnMsg(12, 26, "No space for new dump line:",
		14, (((Vc.screenwidth - len)/2)+1), nd, 2);
	    return(0);
	}
	(void) strcpy(cp, nd);
	(void) sprintf(cp + len, " %04x", sum);
	if (DumpLp[x])
	    (void) free(DumpLp[x]);
	DumpLp[x] = cp;
	return(0);
}


/*
 * StoreDumpLn() - store dump line via DumpLp[]
 */

static int
StoreDumpLn(void)
{
	char *cp;
	int i;
	size_t l;
	char msg[128];

	if (DumpLc >= DUMPNL) {
		(void) sprintf(msg, "Dump buffer is full (limit = %d).",
			DUMPNL);
store_warn:
		i = WarnMsg(12, (short)(((Vc.screenwidth - strlen(msg))/2)+1),
		    msg, 14, (short)(((Vc.screenwidth - strlen(DumpLine))/2)+1),
		    DumpLine, 1);
		return(((char)i == ESC) ? 1 : 0);
	}
	cp = DumpLine;
	if (*cp == DumpMtrCmd[2]) {
		cp++;
		if (*cp == ' ')
			cp++;
	}
	l = (size_t)(strlen(cp) + 1);
	if ((DumpLp[DumpLc] = (char *)malloc(l)) == NULL) {
		(void) sprintf(msg, "No memory for dump line number %d.",
			DumpLc);
		goto store_warn;
	}
	(void) strcpy(DumpLp[DumpLc], cp);
	DumpLc++;
	return(0);
}


/*
 * TrimSpaces() - trim leading and trailing spaces from string
 */

static void
TrimSpaces(s)
	char *s;			/* string address */
{
	char *s1, *s2;
 
	for (s1 = s2 = s; *s1; s1++) {
		if (s2 > s || *s1 != ' ')
			*s2++ = *s1;
	}
	while (s2 > s) {
		if (*(s2 - 1) != ' ')
			break;
		s2--;
	}
	*s2 = '\0';
}


/*
 * WaitRdy() - wait for the meter to become ready
 */

int
WaitRdy(ty)
	int ty;				/* meter type: 0 = ignore MtrTy
					 *	       1 = use MtrTy */
{
	char buf[64], *cp;

	DispMenu(DumpRdy, NULL);
	OpenCom();
	AsynRstBf();
	for (;;) {
	    if (CheckESC())
		return(0);
	    if (AsynBfLen == 0)
			continue;
	    if (GetDispLn(buf, sizeof(buf)) == 0)
		return(0);
	    if (ty == 0 || MtrTy == MTY_UNKNOWN || MtrTy == MTY_ONETOUCH2) {
		if (strcmpi(buf, "INSERT")  == 0	/* ENGL */
		||  strcmpi(buf, "INSERT.") == 0	/* ESPAN */
		||  strcmpi(buf, "INSER. ") == 0	/* FRANC and ITALI */
		||  strcmpi(buf, "IN    ")  == 0	/* NEDER */
		||  strcmpi(buf, "INSIRA")  == 0	/* PORT */
		||  strcmpi(buf, "SATTIN")  == 0	/* SVENS */
		||  strcmpi(buf, "EINLEG")  == 0	/* DEUTS */
		||  strcmpi(buf, ")))   ")  == 0)	/* SYMB */
		{
		    MtrTy = MTY_ONETOUCH2;
		    break;
		}
	    }
	    if (ty == 0 || MtrTy == MTY_UNKNOWN || MtrTy == MTY_PROFILE) {
		if (buf[0] >= '0' && buf[0] <= '3'
		&&  strncmp(&buf[1], ",\"\",", 4) == 0
		&&  buf[5] >= '0' && buf[5] <= '7'
		&&  strncmp(&buf[6], ",\"", 2) == 0) {
		    cp = &buf[8];
		    if (strnicmp(cp, "INSERT", 6) == 0  /* English & British */
		    ||  strnicmp(cp, "PONGA",  5) == 0  /* Spanish */
		    ||  strnicmp(cp, "INSER.", 6) == 0  /* French & Italian */
		    ||  strnicmp(cp, "CSIKOT", 6) == 0  /* Hungarian */
		    ||  strnicmp(cp, "  IN",   4) == 0  /* Dutch */
		    ||  strnicmp(cp, "SETT I", 6) == 0  /* Norwegian */
		    ||  strnicmp(cp, "W<OZYC", 6) == 0  /* Polish */
		    ||  strnicmp(cp, "INSIRA", 6) == 0  /* Portuguese */
		    ||  strnicmp(cp, "BBE;J",  5) == 0  /* Russian */
		    ||  strnicmp(cp, "ASETA",  5) == 0  /* Finnish */
		    ||  strnicmp(cp, "SATTIN", 6) == 0  /* Swedish */
		    ||  strnicmp(cp, "BANTI",  5) == 0  /* Turkish */
		    ||  strnicmp(cp, ")))",    3) == 0  /* SymboL */
		    ||  strnicmp(cp, " VLOZ",  5) == 0  /* Czech */
		    ||  strnicmp(cp, "INDS[T", 6) == 0  /* Danish */
		    ||  strnicmp(cp, "EINLEG", 6) == 0  /* German */
		    ||  strnicmp(cp, "BA^TE",  5) == 0	/* Greek */
		    ) {
			MtrTy = MTY_PROFILE;
			break;
		    }
		}
	    }
	}
	return(GetDispLn(buf, sizeof(buf)));
}


/*
 * WarnCantOpen() - issue can't open file warning
 */

static void
WarnCantOpen(f)
	char *f;			/* file name */
{
	char msg[80];

	(void) sprintf(msg, "Can't open %s", f);
	(void) WarnMsg(12, 1, msg, 0, 0, NULL, 0);
}


/*
 * WarnCksum()
 */

static int
WarnCksum(f, x)

#if	defined(UNIX)
	int f;			/* prompt flag for WarnMsg() */
	int x;			/* index of record in DumpLp[] */
#else
	short f;		/* prompt flag for WarnMsg() */
	int x;			/* index of record in DumpLp[] */
#endif

{
	int i;
	char m1[80], m2[80], m3[DUMPLL+1], *lp;

	(void) strcpy(m1, "Checksum doesn't match for dump ");
	if (x)
		(void) sprintf(m2, "record %d.  ", x);
	else
		(void) strcpy(m2, "header record.  ");
	(void) strcat(m1, m2);
	(void) strcat(m1, CksumErrMsg);
	for (i = 0, lp = DumpLp[x]; i < DUMPLL && *lp; lp++, i++) {
		if (isascii(*lp) && isprint(*lp))
			m3[i] = *lp;
		else
			m3[i] = '?';
	}
	m3[i] = '\0';
	return(WarnMsg(12, (short)(((Vc.screenwidth - strlen(m1))/2)+1), m1,
		14, (short)(((Vc.screenwidth - i)/2)+1), m3, f));
}


/*
 * WarnDumpHdr()
 */

static int
WarnDumpHdr(void)
{
	return(WarnMsg(12, 30, "Bad dump header line:", 14,
		(short)(((Vc.screenwidth - strlen(DumpLine))/2)+1),
		DumpLine, 1));
}


/*
 * WarnDumpLen() - warn about incorrect dump length
 */

static void
WarnDumpLen(void)
{
	char msg[80];

	(void) sprintf(msg,
		"Dump length incorrect: %d records expected, %d received.",
		Ndump, DumpLc - 1);
	(void) WarnMsg(12, 11, msg, 0, 0, NULL, 0);
}


/*
 * WarnExist() - warn that the dump file exists
 */

static int
WarnExist(d, s)
	char *d;			/* dump file name */
	struct stat *s;			/* stat buffer */
{
	char msg[64];

	clrscr();
	(void) sprintf(msg, "%s exists.", d);
	gotoxy((short)((Vc.screenwidth - strlen(msg))/2 + 1), 11);
	(void) cputs(msg);
	(void) sprintf(msg, "It is %ld bytes long.", s->st_size);
	gotoxy((short)((Vc.screenwidth - strlen(msg))/2 + 1), 13);
	(void) cputs(msg);
	PromptMsg("Press ESC to exit; any other key to overwrite.");
	if ((char)WaitAnyKey() == ESC)	
		return(0);
	return(1);
}


/*
 * WarnMsg() - issue warning message
 */

int
WarnMsg(r1, c1, m1, r2, c2, m2, f)

#if	defined(UNIX)
	int r1;				/* first message row */
	int c1;				/* first message column */
	char *m1;			/* first message */
	int r2;				/* second message row */
	int c2;				/* second message column */
	char *m2;			/* second message */
	int f;				/* prompt flag: 0 = any continue
					 *		1 = ESC abort
					 *		2 = any abort */
#else
	short r1;			/* first message row */
	short c1;			/* first message column */
	char *m1;			/* first message */
	short r2;			/* second message row */
	short c2;			/* second message column */
	char *m2;			/* second message */
	short f;			/* prompt flag: 0 = any continue
					 *		1 = ESC abort
					 *		2 = any abort */
#endif

{
	char *p;

	clrscr();
	gotoxy(c1, r1);
	(void) cputs(m1);
	if (m2) {
		gotoxy(c2, r2);
		(void) cputs(m2);
	}
	switch (f) {
	case 0:
		p = "Press any key to continue.";
		break;
	case 1:
		p = "Press ESC to exit; any other key to continue.";
		break;
	default:
		p = "Press any key to abort.";
	}
	PromptMsg(p);
	return(WaitAnyKey());
}


/*
 * WrDumpF() -- write dump lines to dump file
 */

static void
WrDumpF(void)
{

#if	defined(UNIX)
	int i;
#else
	short i;
#endif

	if (Qp) {
		for (i = 1; i < DumpLc; i++) {
			if (ParseDumpLn(DumpLp[i], 0, 0) == 0)
				break;
			(void) TrimSpaces(Date);
			if (Ckdump == 0 && Rtype != RDREG)
				continue;
			(void) TrimSpaces(Time);
			(void) fprintf(Dumpfs, "%s,%s,%6.2f\n", Date, Time,
				Rval);
		}
	} else {
		if (Gttl[0] && !SupTtlIO)
			(void) fprintf(Dumpfs, "TTL:%s\n", Gttl);
		if (DumpMtrTy == MTY_PROFILE)
			(void) fprintf(Dumpfs, "PROFILE:\n");
		for (i = 0; i < DumpLc; i++)
			(void) fprintf(Dumpfs, "%s\n", DumpLp[i]);
	}
	(void) fclose(Dumpfs);
	Dumpfs = NULL;
}
