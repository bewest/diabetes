/*
 * dttm.c - manage date and time
 *
 * V. Abell
 */

/*
 * Copyright 1993, 1994, 1995, 1996 Victor A. Abell, Lafayette, Indiana 47906.
 * All rights reserved.
 *
 * Written by Victor A. Abell.
 *
 * Permission is granted to anyone to use this software for any purpose on
 * any computer system, and to alter it and redistribute it freely, subject
 * to the following restrictions:
 *
 * 1. Victor A. Abell is not responsible for any consequences of the use of
 * this software.
 *
 * 2. The origin of this software must not be misrepresented, either by
 *    explicit claim or by omission.  Credit to Victor A. Abell must
 *    appear in documentation and sources.
 *
 * 3. Altered versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 *
 * 4. This notice may not be removed or altered.
 */

#if	!defined(lint)

# if	defined(_BCC)
#pragma warn -use
# endif

static char copyright[] =
"@(#) Copyright 1993, 1994, 1995, 1996 Victor A. Abell.\nAll rights reserved.\n";
#endif

#include "touch2.h"
#include <ctype.h>


struct menu GetProfEvt[] = {
	{  3, 15, "Select Profile Event." },
#define	PROFEVLN	5
#define	PROFEVCOL	15
	{  0,  0, NULL },
};

struct menu MainDT[] = {
	{  2, 21, "Read and set the meter's date and time." },
	{  9, 21, "R - Read date and time" },
	{ 11, 21, "S - Set date and time" },
	{ 13, 21, "X - eXit" },
#define	PROMPTLN	15
#define	PROMPTCOL	11
	{  0,  0, NULL },
};

struct menu ReadWt[] = {
	{ 12, 26, "Waiting to read date and time" },
	{  0,  0, NULL },
};

struct menu DateErr[] = {
	{ 12, 33, "Date read/set error" },
	{  0,  0, NULL },
};

struct menu SelIgnMenu[] = {
#define	IGNROW	6
#define	IGNCOL	20
	{  3, 20, "E - Erase ignored event numbers" },
	{  4, 20, "X = eXit" },
	{  5, 20, "I - Ignore an event" },
	{  0,  0, NULL },
};

short month_days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

short RangeInUse = 0;			/* index + 1 of TmRange[] that is
					 * in use (0 = none) */
short SkipAft = 0;			/* skip after in effect */
char SkipAftDt[SKIPDTLN];		/* skip after date */
char SkipAftTm[SKIPTMLN];		/* skip after time */
short SkipUnt = 0;			/* skip until in effect */
char SkipUntDt[SKIPDTLN];		/* skip until date */
char SkipUntTm[SKIPTMLN];		/* skip until time */
struct range TmRange[MAXTMRANGE];	/* time ranges */


#if	defined(UNIX)
static char *AsmNum(char *p, int *n);
#else
static char *AsmNum(char *p, short *n);
#endif

static int GetEvtNr(int r);
static void ReadDtTm(void);
static void SetDtTm(void);
static int SkipDtTm(char *ttl, char *dt, char *tm);


/*
 * AsmNum() - assemble number
 */

static char *
AsmNum(p, n)
	char *p;			/* pointer to number string */

#if	defined(UNIX)
	int *n;				/* pointer to result */
#else
	short *n;			/* pointer to result */
#endif

{
	for (*n = 0; *p; p++) {
		if ( ! isdigit(*p))
			break;
		*n = (*n * 10) + *p - '0';
	}
	return(p);
}


/*
 * CommDisp() - display communications input
 */

void
CommDisp(ch)
	char *ch;		/* character to display
				 * NULL = turn display on or off */
{
	static short state = 0;
	static short col = 1;
	static short row = 1;

	if (ch == NULL || ! state) {
		if (state)
			state = 0;
		else {
			col = row = state = 1;
			ClearRow(1,1);
		}
		if (ch == NULL)
			return;
	}
	if (*ch >= ' ' && *ch <= '~') {
		if (col > Vc.screenwidth) {
			col = 1;
			row++;
			if (row >= Vc.screenheight)
				row = 1;
			ClearRow(row, 1);
		}
		gotoxy(col++, row);
		putch(*ch);
		return;
	}
	if (*ch < ' ') {
		if ((col + 1) > Vc.screenwidth) {
			col = 1;
			row++;
			if (row >= Vc.screenheight)
				row = 1;
			ClearRow(row, 1);
		}
		gotoxy(col, row);
		cprintf("^%c", *ch + '@');
		col += 2;
		return;
	}
	if ((col + 3) > Vc.screenwidth) {
		col = 1;
		row++;
		if (row >= Vc.screenheight)
			row = 1;
		ClearRow(row, 1);
	}
	gotoxy(col, row);
	cprintf("0x%02x", (int) *ch);
	col += 4;
}


/*
 * CvtTm() - convert time
 */

int
CvtTm(char **tm, char *msg)
{
	register char *cp;
	int hr, min, nd;

	for (cp = *tm, hr = min = nd = 0; nd < 3 && *cp; cp++) {
		if (*cp == ' ')
			continue;
		if (*cp >= '0' && *cp <= '9') {
			hr = (hr * 10) + (int)(*cp - '0');
			nd++;
		} else
			break;
	}
	if (nd < 1 || nd > 2 || hr > 24) {

bad_hour:
		(void) strcpy(msg, "has a bad hour value.");
		return(-1);
	}
	if (*cp == ':') {
		for (++cp, nd = 0; nd < 3 && *cp; cp++) {
		    if (*cp == ' ')
			continue;
		    if (*cp >= '0' && *cp <= '9') {
			min = (min * 10) + (int)(*cp - '0');
			nd++;
		    } else
			break;
		}
		if (nd != 2 || min > 59) {
		    (void) strcpy(msg, "has a bad minute value.");
		    return(-1);
		}
		if (*cp == ':') {
		    cp++;
		/*
		 * Skip seconds and trailing space.
		 */
		    while (cp && (*cp == ' ' || (*cp >= '0' && *cp <= '9')))
			cp++;
		}
	} else {
		while (*cp && *cp == ' ')
		    cp++;
	}
/*
 * Handle AM suffix.
 */
	if (*cp == 'a' || *cp == 'A') {
		if (hr > 12)
		    goto bad_hour;
		if (hr == 12)
		    hr = 0;
		cp++;
		if (*cp == '.')
		    cp++;
		if (*cp == 'm' || *cp == 'M')
		    cp++;
		else {

bad_AM_PM:

		    (void) strcpy(msg, "has a bad AM/PM indicator.");
		    return(-1);
		}
		if (*cp == '.')
		    cp++;
/*
 * Handle PM suffix.
 */
	} else if (*cp == 'p' || *cp == 'P') {
		if (hr > 12)
		    goto bad_hour;
		if (hr < 12)
		    hr += 12;
		cp++;
		if (*cp == '.')
		    cp++;
		if (*cp == 'm' || *cp == 'M')
		    cp++;
		else
		    goto bad_AM_PM;
		if (*cp == '.')
		    cp++;
	}
	while (*cp && *cp == ' ')
		cp++;
	*tm = cp;
	return((hr * 60) + min);
}


/*
 * CvtTmRange() - convert time range
 */

int
CvtTmRange(tm, msg, bt, et)
	char *tm;			/* time range characters */
	char *msg;			/* error message buffer */
	short *bt;			/* computed start time */
	short *et;			/* computed end time */
{
	char *cp = tm;
	int t;

	(void) strcpy(msg, "The starting hour ");
	if ((t = CvtTm(&cp, &msg[strlen(msg)])) < 0)
		return(0);
	if (*cp != '-') {
		(void) strcpy(msg,
			"The times aren't separated by a minus sign.");
		return(0);
	}
	*bt = (short)t;
	cp++;
	(void) strcpy(msg, "The ending hour ");
	if ((t = CvtTm(&cp, &msg[strlen(msg)])) < 0)
		return(0);
	if (*cp) {
		(void) strcpy(msg,
			"The time range ends with unrecognized characters.");
		return(0);
	}
	*et = (short)t;
	if (*bt == *et) {
		(void) strcpy(msg,
			"The ending time can't equal the starting time.");
		return(0);
	}
	return(1);
}



/*
 * DateTime() - read and set date and time
 */

void
DateTime()
{
	int ch;

	DispMenu(MainDT, NULL);
	for (;;) {
		if ( !kbhit()) {
			AsynRstBf();
			continue;
		}
		if ((ch = getch()) == 0)
			ch = getch();
		switch (ch) {

		case ESC:
		case 'x':
		case 'X':
			return;

		case 'r':
		case 'R':
			ReadDtTm();
			break;

		case 's':
		case 'S':
			SetDtTm();
			break;

		default:
			putch(BELL);
		}
		DispMenu(MainDT, NULL);
	}
}


static int
GetEvtNr(r)
	int r;				/* row for input request */
{
	char ev[3];
	int ch, i, m, row;

	if (MtrTy == MTY_PROFILE) {
	    for (m = 0; m != 2;) {
		if (m == 0) {
		    (void) DispMenu(GetProfEvt, "Press ESC to exit.");
		    for (i = 1, row = PROFEVLN; i < 16; i++, row++) {
			ClearRow(row, 1);
			gotoxy(PROFEVCOL, row);
			cprintf("%x. %s (%s)", i, EventCode[i].nm,
			    EventCode[i].ab);
		    }
		    m = 1;
		}
		if ( ! kbhit()) {
		    AsynRstBf();
		    continue;
		}
		if ((ch = getch()) == ESC) {
		    m = 2;
		    break;
		}
		if (ch >= '1' && ch <= '9')
		    return((int)(ch - '0'));
		else if (ch >= 'a' && ch <= 'f')
		    return((int)(ch - 'a' + 10));
		else if (ch >= 'A' && ch <= 'F')
		    return((int)(ch - 'A' + 10));
		putch(BELL);
		m = 0;
	    }
	    return(0);
	}
	for (m = 0; m == 0;) {
	    ClearRow(r, 1);
	    gotoxy(1, r);
	    cprintf("Press ENTER to end the event group list.");
	    if (GetInp(r+1, 1, "Event number?", NULL, ev, sizeof(ev)) == 0) {
		m = 1;
		break;
	    }
	    if (ev[1] == '\0') {
		if (ev[0] >= '0' && ev[0] <= '9')
		    i = ev[0] - '0';
		else if ((ev[0] >= 'a' && ev[0] <= 'f')
		     ||  (ev[0] >= 'A' && ev[0] <= 'F'))
		{
		    if (islower(ev[0]))
			i = ev[0] - 'a' + 10;
		    else
			i = ev[0] - 'A' + 10;
		} else
		    i = 0;
	    } else
		i = atoi(ev);
	    if (i >= 1 && i <= 15)
		return(i);
	    if ((char)WarnMsg(12, (short)((Vc.screenwidth - 49)/2 + 1),
		"An event number must be 1 - 9, 10 - 15, or a - f.",
		0, 0, NULL, 1)
	    == ESC) {
		m = 1;
		break;
	    }
	    clrscr();
	}
	return(0);
}


/*
 * ReadDtTm() - read the date and time
 */

static void
ReadDtTm()
{
	char b[64], *cp;
	int i;

	for (;;) {
		if (WaitRdy(1) == 0)
			return;
		DispMenu(ReadWt, NULL);
		if (WaitCmd("DMF", 'F'))
			break;
		DispMenu(DateErr,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return;
	}
	GetDataLn(DumpLine, DUMPLL);
	cp = DumpLine;
	if (*cp == 'F') {
		cp++;
		if (*cp == ' ')
			cp++;
	}
	for (i = 0; i < sizeof(b) - 1; cp++) {
		if (*cp == '"')
			continue;
		b[i++] = *cp;
	}
	b[i] = 0;
	ClearRow(12, 1);
	gotoxy(22, 12);
	(void) cputs(b);
	PromptMsg("Press any key to exit.");
	(void) WaitAnyKey();
}


/*
 * SelEvent() - select event filter (and its title)
 */

void
SelEvent()
{
	char ch, ttl[GTTLLNL+1];
	short ex, i, ne;
	int r;

	for (ex = 0; !ex;) {
	    for (i = ne = 0; i < 15; i++) {
		if (EvtBuf[i] != NULL)
		    ne++;
	    }
	    clrscr();
	    PromptMsg("Press ESC to exit.");
	    r = 3;
	    if (ne) {
		ClearRow(r, 1);
		gotoxy(4, r++);
		cprintf("Use one of these event filters by typing its number:");
		for (i = 0; i < 15; i++) {
		    if (EvtBuf[i] == NULL)
			    continue;
		    ClearRow(r, 1);
		    gotoxy(4, r++);
		    if (MtrTy == MTY_PROFILE)
			cprintf("%c %x. %s (%s)",
			    (Eventfilt == (i + 1)) ? '>' : ' ',
			    (i + 1), EvtBuf[i], EventCode[i + 1].ab);
		    else
			cprintf("%c %x. %s",
			    (Eventfilt == (i + 1)) ? '>' : ' ',
			    (i + 1), EvtBuf[i]);
		}
	    }
	    ClearRow(r, 1);
	    gotoxy(4, r++);
	    cprintf("N - define and use a New event filter");
	    if (Eventfilt) {
		ClearRow(r, 1);
		gotoxy(4, r++);
		cprintf("S - Stop using event %x", Eventfilt);
	    }
	    ClearRow(r, 1);
	    gotoxy(4, r);
	    cputs("X - eXit");
	    (void) DispMtrTy();
	    r += 2;
	    ch = (char) WaitAnyKey();
	    if (ch == ESC || ch == 'x' || ch == 'X') {
		ex = 1;
		return;
	    } else if ((ch >= '0' && ch <= '9')
		   ||  (ch >= 'a' && ch <= 'f')
		   ||  (ch >= 'A' && ch <= 'F'))
	    {
		if (isdigit(ch))
		    i = ch - '0';
		else {
		    if (islower(ch))
			i = ch - 'a' + 10;
		    else
			i = ch - 'A' + 10;
		}
		if (i >= 1 && i <= 15 && EvtBuf[i - 1]) {
		    Eventfilt = i;
		    (void) strcpy(Gttl, EvtBuf[i - 1]);
		}
	    } else if (ch == 'n' || ch == 'N') {
		if ((i = GetEvtNr(r)) == 0) {
		    putch(BELL);
		    continue;
		}
		if (MtrTy == MTY_PROFILE)
		    clrscr();
		else {
		    ClearRow(r, 1);
		    ClearRow(r+1, 1);
		}
		if (GetInp(r, 1, "Title?", Gttl, ttl, sizeof(ttl) - 1) == 0)
		    ttl[0] = '\0';
		if (EvtBuf[i - 1])
		    (void) free((void *)EvtBuf[i]);
		if ((EvtBuf[i - 1] = (char *)malloc(strlen(ttl) + 1)) == NULL) {
		    (void) fprintf(stderr, "%s: no space for title: %s\n",
			Pn, ttl);
			exit(1);
		}
		(void) strcpy(EvtBuf[i - 1], ttl);
		Eventfilt = i;
		(void) strcpy(Gttl, ttl);
	    } else if (Eventfilt && (ch == 's' || ch == 'S')) {
		Eventfilt = 0;
		(void) strcpy(Gttl, GttlOrig);
	    } else
		putch(BELL);
	}
}


/*
 * SelEvtGrp() - select group of events
 */

void
SelEvtGrp()
{
	char ch, *tp, ttl[GTTLLNL+1];
	struct evtgrpe *eg, *egc, *egh, *egn;
	short ct, ex, g, i, j, ng;
	int r;

	for (ex = 0; !ex; ) {
	    clrscr();
	    PromptMsg("Press ESC to exit.");
	/*
	 * Display the current groups.
	 */
	    for (ng = i = 0; i < NEVTGRP; i++) {
		if (EvtGrp[i].grp)
		    ng++;
	    }
	    r = 3;
	    if (ng) {
		ClearRow(r, 1);
		gotoxy(6, r++);
		cprintf("Use one of these event groups by typing its number:");
	        for (g = -1, i = 0; i < NEVTGRP; i++) {
		    if ( ! (eg = EvtGrp[i].grp))
			continue;
		    ClearRow(r, 1);
		    if (EEvtGrp && EEvtGrp == &EvtGrp[i])
			g = i;
		    gotoxy(6, r++);
		    cprintf("%c %01d. ", (g == i) ? '>' : ' ', i);
		    while (eg) {
			cprintf(" %x", eg->grp);
			eg = eg->next;
		    }
		    if (EvtGrp[i].ttl)
			cprintf(" \"%s\"", EvtGrp[i].ttl);
	        }
	    }
	/*
	 * Display the remainder of the menu.
	 */
	    if (ng) {
		ClearRow(r, 1);
		gotoxy(6, r++);
		cprintf("D - Delete an event group");
	    }
	    ClearRow(r, 1);
	    gotoxy(6, r++);
	    cprintf("N - define and use a New event group");
	    if (g != -1) {
		ClearRow(r, 1);
		gotoxy(6, r++);
		cprintf("S - Stop using event group %01d", g);
	    }
	    ClearRow(r, 1);
	    gotoxy(6, r);
	    cprintf("X - eXit");
	    (void) DispMtrTy();
	    r += 2;
	/*
	 * Get a response character.
	 */
	    ch = (char) WaitAnyKey();
	    if (ch == ESC || ch == 'x' || ch == 'X') {

	    /*
	     * ESC, x, or X -- exit.
	     */
		ex = 1;
		break;
	    } else if (ng && (ch >= '0' && ch <= '9')) {
	
	    /*
	     * 0 through 9, select the associated group.
	     */
		i = ch - '0';
		if ( ! EvtGrp[i].grp) {
		    putch(BELL);
		    continue;
		}
		EEvtGrp = &EvtGrp[i];
		if (EEvtGrp->ttl)
		    (void) strcpy(Gttl, EEvtGrp->ttl);
		else
		    Gttl[0] = '\0';
		Eventfilt = 0;
		for (i = 0; i < 15; i++)
		    IgnEvt[i] = 0;
	    } else if (ng && (ch == 'd' || ch == 'D')) {

	    /*
	     * Delete a defined group.
	     */
		if (GetInp(r, 1, "Number of group to delete?", NULL, ttl,
			sizeof(ttl))
		== 0)
		    continue;
		j = atoi(ttl);
		if ( ! EvtGrp[j].grp)
		    putch(BELL);
		else {
		    if (EEvtGrp == &EvtGrp[i])
			EEvtGrp = (struct evtgrpe *)NULL;
		    DelEvtGrp(EvtGrp[j].grp, EvtGrp[j].ttl);
		    EvtGrp[j].grp = (struct evtgrpe *)NULL;
		    EvtGrp[j].ttl = (char *)NULL;
		    ng--;
	        }
	    } else if (ch == 'n' || ch == 'N') {

	    /*
	     * N or n -- define a new event group.
	     */
		if (ng >= NEVTGRP) {
		    (void)WarnMsg(11, 17,
			"No available group numbers; delete one first.",
			0, 0, NULL, 1);
		    continue;
		}
		egc = egh = (struct evtgrpe *)NULL;
	    /*
	     * Get event numbers and build a group structure chain.
	     */
		for (ct = 0, i = 1; i; ) {
		    if ((i = GetEvtNr(r)) == 0)
			break;
		    if ((eg = (struct evtgrpe *)malloc(sizeof(struct evtgrpe)))
		    == (struct evtgrpe *)NULL) {
			(void) fprintf(stderr,
			    "%s: no space for new event group entry\n", Pn);
			exit(1);
		    }
		    if ( ! egc)
			egh = eg;
		    else
			egc->next = eg;
		    eg->grp = i;
		    eg->next = (struct evtgrpe *)NULL;
		    egc = eg;
		    ct++;
		}
		if (MtrTy == MTY_PROFILE)
		    clrscr();
		else {
		    ClearRow(r, 1);
		    ClearRow(r+1, 1);
		}
		if (ct == 0) {
		    (void) WarnMsg(12, 25, "The event group list is empty.",
			0, 0, NULL, 0);
		    continue;
		}
	    /*
	     * Get the title for the event group.
	     */
		if (GetInp(r, 1, "Title?", Gttl, ttl, sizeof(ttl) - 1) == 0)
		    ttl[0] = '\0';
		if ((tp = (char *)malloc(strlen(ttl) + 1)) == (char *)NULL) {
		    (void) fprintf(stderr,
			"%s: no space for event group title\n", Pn);
		    exit(1);
		}
		(void) strcpy(tp, ttl);
	    /*
	     * Find an event group table slot.
	     * Discard the last one if the table is full.
	     */
		for (g = 0; g  < NEVTGRP; g++) {
		    if ( ! EvtGrp[g].grp)
			break;
		}
		if (g >= NEVTGRP) {
		    (void) fprintf(stderr,
			"%s: internal event group count error: %d\n", Pn, ng);
		    exit(1);
		}
	    /*
	     * Make the new event group the effective one.
	     */
		EvtGrp[g].grp = egh;
		EvtGrp[g].ttl = tp;
		EEvtGrp = &EvtGrp[g];
		(void) strcpy(Gttl, ttl);
		Eventfilt = 0;
		for (i = 0; i < 15; i++)
		    IgnEvt[i] = 0;
		ng++;
	    } else if (ch == 's' || ch == 'S') {
	
	    /*
	     * S or s -- suspend use of the effective event group.
	     */
		EEvtGrp = (struct evtgrphd *)NULL;
		(void) strcpy(Gttl, GttlOrig);
	    } else
		putch(BELL);
	}
}


/*
 * SelIgnEvt() - select ignored events
 */

void
SelIgnEvt()
{
	char buf[128], *cp;
	short i, j, m;
	int r;

	for (m = 0; m == 0;) {
		DispMenu(SelIgnMenu, NULL);
		for (i = 1, r = IGNROW; i < 16; i++) {
			if (IgnEvt[i - 1] == 0)
				continue;
			ClearRow(r, 1);
			gotoxy(IGNCOL + 4, r++);
			if (MtrTy == MTY_PROFILE)
				cprintf("%s (%s) [%x (%d)]", EventCode[i].nm,
					EventCode[i].ab, i, i);
			else
				cprintf("%x (%d)", i, i);
		}
		r++;
		switch((char)WaitAnyKey()) {
		case ESC:
		case 'x':
		case 'X':
			m = 1;
			break;
		case 'e':
		case 'E':
			for (i = 0; i < 15; i++)
				IgnEvt[i] = 0;
			break;
		case 'i':
		case 'I':
			if ((i = GetEvtNr(r)) == 0)
				break;
			IgnEvt[i - 1] = 1;
			break;
		default:
			putch(BELL);
		}
	}
}


/*
 * SelSkipAft() - select skip after
 */

void
SelSkipAft()
{
	char dt[SKIPDTLN], tm[SKIPTMLN];

	if (SkipDtTm("AFTER", dt, tm) == 1) {
		SkipAft = 1;
		(void) strcpy(SkipAftDt, dt);
		(void) strcpy(SkipAftTm, tm);
	}
}


/*
 * SelSkipUnt() - select skip until
 */

void
SelSkipUnt()
{
	char dt[SKIPDTLN], tm[SKIPTMLN];

	if (SkipDtTm("UNTIL", dt, tm) == 1) {
		SkipUnt = 1;
		(void) strcpy(SkipUntDt, dt);
		(void) strcpy(SkipUntTm, tm);
	}
}


/*
 * SelTmRange() - select time range
 */

void
SelTmRange()
{
	char ch;
	short bt, bufl, ct, et, ex, i, j, m, msgl;
	char buf[GTTLLNL+1];
	char msg[128];
	char ttl[GTTLLNL+1];

	for (ex = 0; !ex;) {
		clrscr();
		PromptMsg("Press ESC to exit.");
		for (ct = i = 0; i < MAXTMRANGE; i++) {
		    if (TmRange[i].tm)
				ct++;
		}
		j = 3;
		if (ct) {
		    ClearRow(j, 1);
		    gotoxy(6, j++);
		    cprintf("Use one of these ranges by typing its number:");
		}
		for (i = 0; i < MAXTMRANGE; i++) {
		    if (TmRange[i].tm == (char *)NULL)
			continue;
		    ClearRow(j, 1);
		    gotoxy(6, j++);
		    cprintf("%c %d.  %s (%d:%02d-%d:%02d)",
			(RangeInUse == i+1) ? '>' : ' ',
			i+1, TmRange[i].tm,
			TmRange[i].bt / 60, TmRange[i].bt % 60,
			TmRange[i].et / 60, TmRange[i].et % 60);
		    if (TmRange[i].ttl) {
			ClearRow(j, 1);
			gotoxy(12, j++);
			cprintf("\"%s\"", TmRange[i].ttl);
		    }
		}
		if (ct) {
		    ClearRow(j, 1);
		    gotoxy(6, j++);
		    cprintf("D - Delete range");
		}
		ClearRow(j, 1);
		gotoxy(6, j++);
		cprintf("N - define New range");
		if (RangeInUse > 0) {
		    ClearRow(j, 1);
		    gotoxy(6, j++);
		    cprintf("S - Stop using range %d.", RangeInUse);
		}
		ClearRow(j, 1);
		gotoxy(6, j);
		cputs("X - eXit");
		switch((ch = (char)WaitAnyKey())) {
		case 'x':
		case 'X':
		case ESC:
		    ex = 1;
		    break;
		case 'd':
		case 'D':
		    if ( ! ct) {
			putch(BELL);
			break;
		    }
		    if (GetInp(21, 5, "Range Number to delete?", "", buf, 2)
		    == 0)
			break;
		    if ((i = buf[0] - '0' - 1) < 0 || i >= MAXTMRANGE 
		    ||  ! TmRange[i].tm) {
			putch(BELL);
			break;
		    }
		    (void) free((void *)TmRange[i].tm);
		    if (TmRange[i].ttl)
			(void) free((void *)TmRange[i].ttl);
		    TmRange[i].tm = TmRange[i].ttl = (char *)NULL;
		    if (RangeInUse == (i + 1))
			RangeInUse = 0;
		    break;
		case 'n':
		case 'N':
		    for (i = 0; i < MAXTMRANGE; i++) {
			if ( ! TmRange[i].tm)
				    break;
		    }
		    if (i >= MAXTMRANGE) {
			(void)WarnMsg(12, 22,
			    "No ranges available; delete one first",
			    0, 0, NULL, 1);
			break;
		    }
		    for (m = 0; m == 0;) {
			if (GetInp(21, 5, "Range?", "", buf, sizeof(buf)) == 0)
			    m = 1;
			else {
			    bufl = strlen(buf);
			    if (CvtTmRange(buf, msg, &bt, &et))
				m = 2;
			    else {
				msgl = strlen(msg);
				(void) WarnMsg(11,
				    (short)((Vc.screenwidth - bufl)/2 + 1),
				    buf, 13,
				    (short)((Vc.screenwidth - msgl)/2 + 1),
				    msg, 0);
				m = 1;
			    }
			}
		    }
		    if (m == 1)
			break;
		    ttl[0] = '\0';
		    if (GetInp(21, 5, "Title?", Gttl, ttl, sizeof(ttl) - 1)
		    == 0)
			    ttl[0] = '\0';
		    TmRange[i].bt = bt;
		    TmRange[i].et = et;
		    if ((TmRange[i].tm = (char *)malloc(bufl + 1)) == NULL) {
			(void) fprintf(stderr,
			    "%s: no space for time range: %s\n", Pn, buf);
			exit(1);
		    }
		    (void) strcpy(TmRange[i].tm, buf);
		    if ((TmRange[i].ttl = (char *)malloc(strlen(ttl) + 1))
		    == NULL) {
			(void) fprintf(stderr, "%s: no space for title: %s\n",
			    Pn, ttl);
			exit(1);
		    }
		    (void) strcpy(TmRange[i].ttl, ttl);
		    (void) strcpy(Gttl, ttl);
		    RangeInUse = i + 1;
		    break;
		case 's':
		case 'S':
		    if (RangeInUse > 0) {
			RangeInUse = 0;
			(void) strcpy(Gttl, GttlOrig);
		    } else
			putch(BELL);
		    break;
		default:
		    i = (short)(ch - '0') - 1;
		    if (i < 0 || i >= MAXTMRANGE || TmRange[i].tm == NULL) {
			putch(BELL);
			break;
		    }
		    (void) strcpy(Gttl, TmRange[i].ttl ? TmRange[i].ttl : "");
		    RangeInUse = i + 1;
		}
	}
}
 

/*
 * SetDtTm() - set the date and time
 */

static void
SetDtTm()
{
	char buf[19], cmd[32], *cp;
	int err;

#if	defined(UNIX)
	int day, hr, min, mo, sec, yr;
#else
	short day, hr, min, mo, sec, yr;
#endif
	int nc;

	for (buf[0] = '\0', err = 0;;) {
		ClearRow(PROMPTLN, PROMPTCOL);
		if (err) {
			putch(BELL);
			err = 0;
		}
		buf[17] = '\0';
		nc = GetInp(PROMPTLN, PROMPTCOL,
			"Enter date/time (mm/dd/yy hh:mm[:ss) ? ", buf, buf,
			sizeof(buf));
		if (nc == 0)
			return;
		err++;
		cp = AsmNum(buf, &mo);
		if (*cp++ != '/' || mo < 1 || mo > 12)
			continue;
		cp = AsmNum(cp, &day);
		if (*cp++ != '/' || day < 1 || day > 31)
			continue;
		cp = AsmNum(cp, &yr);
		if (*cp++ != ' ' || (yr > 14 && yr < 84))
			continue;
		if (mo == 2) {
			nc = (yr >= 84) ? yr + 1900 : yr + 2000;
			if ((((nc % 4) == 0) && ((nc % 100) != 0))
			|| ((nc % 400) == 0))
				month_days[1] = 29;
			else
				month_days[1] = 28;
		}
		if (day > month_days[mo - 1])
			continue;
		cp = AsmNum(cp, &hr);
		if (*cp++ != ':' || hr < 0 || hr > 23)
			continue;
		cp = AsmNum(cp, &min);
		if (min < 0 || min > 59)
			continue;
		if (*cp == ':') {
			cp = AsmNum(++cp, &sec);
			if (sec < 0 || sec > 59)
				continue;
		} else
			sec = 0;
		if (*cp != '\0')
			continue;
		(void) sprintf(cmd, "DMT%02d/%02d/%02d %02d:%02d:%02d",
			mo, day, yr, hr, min, sec);
		for (;;) {
			if (WaitRdy(1) == 0)
				return;
			DispMenu(ReadWt, NULL);
			if (WaitCmd(cmd, 'T')) {
				GetDataLn(DumpLine, DUMPLL);
				if (DumpLine[0] == ' ' && DumpLine[1] == '"')
					break;
			}
			DispMenu(DateErr,
				"Press ESC to exit; any other key to retry.");
			gotoxy(1, 14);
			cprintf("Command response: %s", DumpLine);
			if ((char)WaitAnyKey() == ESC)
				return;
			continue;
		}
		return;
	}
}


/*
 * SkipDtTm() - get skip date and time
 */

int
SkipDtTm(ttl, dt, tm)
	char *ttl;		/* title line */
	char *dt;		/* date destination */
	char *tm;		/* time destination */
{
	char buf[64];
	short dtl, i, j, k, tml;

	for (;;) {
	    for (i = 0; i < 2;) {
		clrscr();
		(void) DispMtrTy();
		gotoxy(10, 10);
		cprintf("Enter some starting characters of the %s %s which",
			(i == 0) ? "date" : "time",
			ttl);
		gotoxy(10, 11);
		cputs("records are to be skipped; enter at least 1 character.");
		if (i == 0) {

		/*
		 * Get date.
		 */
		    if (GetInp(13, 10, "Date?", "", dt, SKIPDTLN) == 0)
			return(0);
		    dtl = strlen(dt);
		    if (dtl > 1 && dtl < (SKIPDTLN - 1) && *dt != ' '
		    &&  *(dt+1) == '/') {
			(void) strcpy(&buf[1], dt);
			buf[0] = ' ';
			(void) strcpy(dt, buf);
			dtl++;
	 	    }
		    i = 1;
		    continue;
		 }
	    /*
	     * Get time.
	     */
		if (GetInp(13, 10, "Time?", "", tm, SKIPTMLN) == 0)
		    return(0);
		tml = strlen(tm);
		if (tml > 1 && tml < (SKIPTMLN - 1) && *tm != ' '
		&&  *(tm+1) == ':') {
		    (void) strcpy(&buf[1], tm);
		    buf[0] = ' ';
		    (void) strcpy(tm, buf);
		    tml++;
		}
		break;
	    }
	/*
	 * Check for matching date and time in dump buffer.
	 */
	    for (j = DumpHs; j < DumpLc; j++) {
		k = ParseDumpLn(DumpLp[j], 0, 0);
		if (k == 1 || k == 2) {
		    if (strncmp(Date, dt, dtl) == 0
		    &&  strncmp(Time, tm, tml) == 0)
			break;
		}
	    }
	    if (j < DumpLc) {

	    /*
	     * Display matching dump record.
	     */
		(void) sprintf(buf,
		    "This record has matching date and time (\"%s\",\"%s\"):",
		    dt, tm);
		if ((char)WarnMsg(11,
		    (short)(((Vc.screenwidth - strlen(buf))/2) + 1), buf,
		    13,
		    (short)(((Vc.screenwidth - strlen(DumpLp[j]))/2) + 1),
		    DumpLp[j], 1)
		== ESC)
		    continue;
	        break;
	    }
	    (void) sprintf(buf,
		"No record has a date and time of \"%s\",\"%s\".",
		dt, tm);
	    if ((char)WarnMsg(12, (short)(((Vc.screenwidth - strlen(buf))/2)+1),
		buf, 0, 0, NULL, 1)
	    == ESC)
		return(0);
	}
	return(1);
}


/*
 * WaitCmd() - issue command and wait for reply
 */

int
WaitCmd(c, e)
	char *c;                        /* command text */

#if	defined(UNIX)
	int e;				/* command echo character */
#else
	char e;				/* command echo character */
#endif

{
	char ch;
	int err;

	AsynRstBf();
	AsynSndStr(c, &err);
	if (err) {
	    switch (err) {
	    case 8:
		(void) sprintf(DumpLine, "COM%d send time out error",
			Port + 1);
		break;
	    case 10:
		(void) sprintf(DumpLine, "COM%d send port is not initialized.",
			Port + 1);
		break;
	    default:
		(void) sprintf(DumpLine, "Unknown COM%d send error: %d",
			Port + 1, err);
	    }
		(void) WarnMsg(12,
			(short)(((Vc.screenwidth - strlen(DumpLine))/2) + 1),
			DumpLine, 0, 0, NULL, 0);
		return(0);
	}
	do {
		if (CheckESC()) {
			err = -1;
			break;
		}
		AsynInp(&ch, &err);
		if (Debug &&  ! err && ch)
			CommDisp(&ch);
	} while (err == 6 || (err == 0 && ch != e));
	if ( ! err)
		return(1);
	if (err == -1)
		return(0);
	(void) sprintf(DumpLine, "Error reading command reply: %d", err);
	(void) WarnMsg(12, (short)(((Vc.screenwidth - strlen(DumpLine))/2)+1),
		DumpLine, 0, 0, NULL, 0);
	return(0);
}
