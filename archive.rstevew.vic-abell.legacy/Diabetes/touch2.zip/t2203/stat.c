/*
 * stat.c - manage meter status
 *
 * V. Abell
 */

/*
 * Copyright 1993, 1994, 1995, 1996 Victor A. Abell, Lafayette, Indiana 47906.
 * All rights reserved.
 *
 * Written by Victor A. Abell.
 *
 * Permission is granted to anyone to use this software for any purpose on
 * any computer system, and to alter it and redistribute it freely, subject
 * to the following restrictions:
 *
 * 1. Victor A. Abell is not responsible for any consequences of the use of
 * this software.
 *
 * 2. The origin of this software must not be misrepresented, either by
 *    explicit claim or by omission.  Credit to Victor A. Abell must
 *    appear in documentation and sources.
 *
 * 3. Altered versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 *
 * 4. This notice may not be removed or altered.
 */

#if	!defined(lint)

# if	defined(_BCC)
#pragma warn -use
# endif

static char copyright[] =
"@(#) Copyright 1993, 1994, 1995, 1996 Victor A. Abell.\nAll rights reserved.\n";
#endif

#include "touch2.h"
#include <string.h>
#include <ctype.h>

struct menu BaudMenu[] = {
	{ 12, 19, "Changing the baud rate is not permitted." },
	{  0,  0,  NULL },
};

struct menu CmdFail[] = {
	{ 12, 32, "Command failed" },
	{  0,  0, NULL },
};

struct menu LangMenu[] = {
	{  2, 32, "Change Language" },
	{  4, 24, "0 - English       1 - Spanish" },
	{  6, 24, "2 - French        3 - Italian" },
	{  8, 24, "4 - Dutch         5 - Portuguese" },
	{ 10, 24, "6 - Swedish       7 - German" },
	{ 12, 24, NULL },				/* 8 and 9 */
#define	LANGL8	5
	{ 14, 24, NULL },				/* A and B */
#define	LANGLA	6
	{ 16, 24, NULL },				/* C and D */
#define	LANGLC	7
	{ 18, 24, NULL },				/* E and F */
#define	LANGLE	8
	{ 20, 24, NULL },				/* G and H */
#define	LANGLG	9
	{ 22, 24, NULL },				/* J and ... */
#define	LANGLJ	10
	{  0,  0, NULL },
};

struct langnm {
	char *ab;		/* meter's abbreviation */
	char *nm;		/* name */
	char c;			/* language code */
};
static struct langnm LangName[] = {
	{ "ENGL.  ",	"English",	'0' },
	{ "ESPAN. ",	"Spanish",	'1' },
	{ "FRANC. ",	"French",	'2' },
	{ "ITALIA",	"Italian",	'3' },
	{ "NEDER. ",	"Dutch",	'4' },
	{ "PORT.  ",	"Portuguese",	'5' },
	{ "SVENS. ",	"Swedish",	'6' },
	{ "DEUTS. ",	"German",	'7' },
	{ "OXOOXO",	"Symbolic",	'8' },
	{ "DANSK ",	"Danish",	'9' },
	{ "SUOMI ",	"Finnish",	'A' },
	{ "NORSK ",	"Norwegian",	'B' },
	{ "POLSKI",	"Polish",	'C' },
	{ "MAGYAR",	"Hungarian",	'D' },
	{ "TURKCE",	"Turkish",	'E' },
	{ "CESKY ",	"Czech",	'F' },
	{ "E^^/KA",	"Greek",	'G' },
	{ "PRCCK. ",	"Russian",	'H' },
	{ "BRIT  ",	"British",	'J' },
	{ NULL,		"",		'\0' }
};

struct menu McommMenu[] = {
	{ 12, 14, "Changing the communications mode is not permitted." },
	{  0,  0,  NULL },
};

struct menu StatusType[] = {
	{  2, 25, "Inspect or change meter status." },
	{ 10, 25, "C - Change meter status" },
	{ 12, 25, "I - Inspect meter status" },
	{ 14, 25, "X - eXit" },
	{  0,  0, NULL},
};

#define	COL		15
#define STATLL		16
#define	VERSLL		24


char Mbaud[STATLL];			/* baud rate */
char Mbeep[STATLL];			/* beeper */
char Mcal[STATLL];			/* calibration */
char Mcomm[STATLL];			/* communications mode */
char Mdate[STATLL];			/* date format */
char Mevavgs[STATLL];			/* Profile event averages setting */
char Minspr[STATLL];			/* Profile insulin prompt */
char Mlang[STATLL];			/* language */
char Mlangtr[STATLL];			/* Profile language translation */
char Mmax[STATLL];			/* maximum reading */
char Mmin[STATLL];			/* minimum reading */
char Mndmark[STATLL];			/* Profile new-data-marker */
char Mpunc[STATLL];			/* mmol/L punctuation */
char Mserial[STATLL];			/* meter serial number */
char Mtime[STATLL];			/* time format */
char Munits[STATLL];			/* mmol/L units */
char Mversion[VERSLL];			/* Profile version and date */
short Ndump = 0;			/* number of dump lines */

static int ChangeBeep(void);
static int ChangeCal(void);
static int ChangeDate(void);
static int ChangeEvAvgs(void);
static int ChangeInspr(void);
static int ChangeLang(void);
static int ChangeMcomm(void);
static int ChangePunc(void);
static int ChangeNdMark(void);
static int ChangeBaud(void);
static int ChangeTime(void);
static int ChangeUnits(void);
static int CopyNdMark(void);

#if	defined(UNIX)
static void CopyReply(char *s, char *d, int dl);
#else
static void CopyReply(char *s, char *d, short dl);
#endif

static int ReadNdMark(void);
static int ReadSerial(void);

#if	defined(UNIX)
static int ReadVal(int c, char *b, int bl);
#else
static int ReadVal(char c, char *b, short bl);
#endif

static int ReadVers(void);
static void StatusCh(void);
static void StatusIn(void);
static void StatusMenu(char *t, char *b, int ty);

#if	defined(UNIX)
static int WriteVal(char *c, char *r, int rl);
#else
static int WriteVal(char *c, char *r, short rl);
#endif


/*
 * ChangeBaud() - change baud rate (not permitted)
 */

static int
ChangeBaud(void)
{
	DispMenu(BaudMenu, "Press any key to continue.");
	(void) WaitAnyKey();
	return(1);
}


/*
 * ChangeBeep() - change beep status
 */

static int
ChangeBeep(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "Beep or nobeep?", "", b, sizeof(b)) == 0)
			return(0);
		if (strcmpi(b, "beep") == 0) {
			b[1] = '0';
			break;
		} else if (strcmpi(b, "nobeep") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'B';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mbeep, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeCal() - change the strip lot calibration code
 */

static int
ChangeCal(void)
{
	char b[4], r[STATLL];
	int n;

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "1 through 16?", "", b, sizeof(b)) == 0)
			return(0);
		n = atoi(b);
		if (n >= 1 && n <= 16)
			break;
		putch(BELL);
	}
	*b = 'S';
	b[1] = (n < 11) ? (char)(n - 1 + '0') : (char)(n - 11 + 'A');
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mcal, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeDate() - change date format
 */

static int
ChangeDate(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "M.D.Y or D.M.Y?", "", b, sizeof(b)) == 0)
			return(0);
		if (strcmpi(b, "m.d.y") == 0) {
			b[1] = '0';
			break;
		} else if (strcmpi(b, "d.m.y") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'D';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mdate, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeEvavgs() - change Profile event averages status
 */

static int
ChangeEvAvgs(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "Event Averages AVGS or NOAVGS?", "", b,
			sizeof(b)) == 0)
		{
			return(0);
		}
		if (strcmpi(b, "NOAVGS") == 0) {
			b[1] = '0';
			break;
		} else if (strcmpi(b, "AVGS") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'E';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mevavgs, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeInspr() - change Profile Insulin prompt
 */

static int
ChangeInspr(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "Insulin prompt INSL or NOINSL?", "", b,
			sizeof(b)) == 0)
		{
			return(0);
		}
		if (strcmpi(b, "NOINSL") == 0) {
			b[1] = '0';
			break;
		} else if (strcmpi(b, "INSL") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'I';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Minspr, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeLang() - change meter language
 */

static int
ChangeLang(void)
{
	char b[8], r[STATLL];
	int ch, end, lx, ms;

	if (MtrTy == MTY_ONETOUCH2) {
		LangMenu[LANGL8].msg = "8 - Symbolic";
		LangMenu[LANGLA].msg = (char *)NULL;
		LangMenu[LANGLC].msg = (char *)NULL;
		LangMenu[LANGLE].msg = (char *)NULL;
		LangMenu[LANGLG].msg = (char *)NULL;
		LangMenu[LANGLJ].msg = (char *)NULL;
	} else {
		LangMenu[LANGL8].msg = "8 - Symbolic      9 - Danish";
		LangMenu[LANGLA].msg = "A = Finnish       B - Norwegian";
		LangMenu[LANGLC].msg = "C - Polish        D - Hungarian";
		LangMenu[LANGLE].msg = "E - Turkish       F - Czech";
		LangMenu[LANGLG].msg = "G - Greek         H - Russian";
		LangMenu[LANGLJ].msg = "J - British";
	}
	for (end = ms = 0; end == 0;) {
		if ( ! ms) {
			DispMenu(LangMenu, "Press ESC to exit.");
			ms++;
		}
		if ( ! kbhit()) {
			AsynRstBf();
			continue;
		}
		ms = 0;
		ch = getch();
		if ((char)ch == ESC)
			return(1);
		if ((char)ch >= '0' && (char)ch <= '8')
			break;
		if ((char)ch == '9'
		||  ((char)ch >= 'a' && (char)ch <= 'h')
		||  ((char)ch >= 'A' && (char)ch <= 'H')
		||  (char)ch == 'j'
		||  (char)ch == 'J')
		{
			if (MtrTy != MTY_ONETOUCH2) {
				ch = (int) (islower((char)ch)
						   ? toupper((char)ch)
						   : ch);
				break;
			}
		}
		if (((char)ch >= 'A' && (char)ch <= 'H') || (char)ch == 'J') {
			if (MtrTy != MTY_ONETOUCH2)
				break;
		}
		putch(BELL);
	}
	*b = 'L';
	b[1] = (char)ch;
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mlang, r);
		Mbeep[0] = Mcal[0] = Mpunc[0] ='\0';
		return(1);
	}
	return(0);
}


/*
 * ChangeMcomm() - change the communications mode (not permitted)
 */

static int
ChangeMcomm(void)
{
	DispMenu(McommMenu, "Press any key to continue.");
	(void) WaitAnyKey();
	return(1);
}


/*
 * ChangeNdMark() - change Profile new-data-marker
 */

static int
ChangeNdMark()
{
	char b[8], c[16];
	int n;

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "New-data-marker (0 through 250)?", "", b,
			sizeof(b)) == 0)
		{
			return(0);
		}
		if ((n = atoi(b)) >= 0 && n <= 250)
			break;
		putch(BELL);
	}
	(void) sprintf(c, "DM^%d", n);
	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd(c, '^')) {
			(void) GetDataLn(DumpLine, DUMPLL);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	return(CopyNdMark());
}


/*
 * ChangePunc() - change punctuation
 */

static int
ChangePunc(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "DEC PT or COMMA?", "", b, sizeof(b)) == 0)
			return(0);
		if (strcmpi(b, "dec pt") == 0) {
			b[1] = '0';
			break;
		} else if (strcmpi(b, "comma") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'P';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mpunc, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeTime() - change time format
 */

static int
ChangeTime(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "AM/PM or 24:00?", "", b, sizeof(b)) == 0)
			return(0);
		if (strcmpi(b, "am/pm") == 0) {
			b[1] = '0';
			break;
		} else if (strcmp(b, "24:00") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'T';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Mtime, r);
		return(1);
	}
	return(0);
}


/*
 * ChangeUnits() - change units
 */

static int
ChangeUnits(void)
{
	char b[8], r[STATLL];

	for (;;) {
		clrscr();
		if (GetInp(12, 10, "mg/dL or mmol/L?", "", b, sizeof(b)) == 0)
			return(0);
		if (strcmpi(b, "mg/dl") == 0) {
			b[1] = '0';
			break;
		} else if (strcmpi(b, "mmol/l") == 0) {
			b[1] = '1';
			break;
		}
		putch(BELL);
	}
	*b = 'U';
	b[2] = '\0';
	if (WriteVal(b, r, sizeof(r))) {
		(void) strcpy(Munits, r);
		return(1);
	}
	return(0);
}


/*
 * CopyNdMark() - copy Profile new-data-marker
 */

static int
CopyNdMark()
{
	char *cp;
	int i;

	cp = DumpLine;
	if (!*cp || *cp != ' ') {
		Mndmark[0] = '\0';
		return(1);
	}
	for (cp++, i = 0; *cp && i < (sizeof(Mndmark) - 1); cp++) {
		if (*cp == ' ') {
			if (i)
				break;
			continue;
		}
		if (*cp < '0' || *cp > '9')
			return(0);
		Mndmark[i++] = *cp;
	}
	Mndmark[i] = '\0';
	return(1);
}


/*
 * CopyReply() - copy command reply
 */

static void
CopyReply(s, d, dl)
	char *s;			/* source */
	char *d;			/* destination */
	short dl;			/* destination limit */
{
	short i;

	for (i = 0; i < dl - 1; i++) {
		if (*s == '\0' || *s == '"')
			break;
		*d++ = *s++;
	}
	*d = '\0';
}


/*
 * InitStatus() - initialize status
 */

void
InitStatus(void)
{
	Mbaud[0] =
	Mbeep[0] =
	Mcal[0] =
	Mcomm[0] =
	Mdate[0] =
	Mevavgs[0] =
	Minspr[0] =
	Mlang[0] =
	Mlangtr[0] =
	Mndmark[0] =
	Mpunc[0] =
	Mserial[0] =
	Mtime[0] =
	Munits[0] =
	Mversion[0] =
			'\0';
}


/*
 * ParseField() - parse '"' delimited field
 */

char *
ParseField(p, b, l)
	char *p;			/* field pointer */
	char *b;			/* destination buffer */
	int l;				/* destination length */
{
	int i;

	if ((p = strchr(p, '"')) == NULL)
		return(NULL);
	for (p++, i = 0; *p; p++, i++) {
		if (*p == '"')
			break;
		if (i > (l - 2))
			return(NULL);
		b[i] = *p;
	}
	b[i] = '\0';
	return(++p);
}


/*
 * ParseHdr() - parse dump header
 */

int
ParseHdr(void)
{
	char *cp;
	int i;

	DumpHs = 0;
/*
 * Get record count.
 */
	if ((cp = strchr(DumpLine, ' ')) == NULL)
		return(0);
	while(*cp == ' ') {
		cp++;
	}
	for (Ndump = 0; *cp; cp++) {
		if ( ! isdigit(*cp))
			break;
		Ndump = Ndump * 10 + *cp - '0';
	}
/*
 * Get serial number.
 */
	if ((cp = ParseField(cp, Mserial, sizeof(Mserial))) == NULL)
		return(0);
/*
 * Get language code.
 */
	if ((cp = ParseField(cp, Mlang, sizeof(Mlang))) == NULL)
		return(0);
/*
 * Get date format.
 */
	if ((cp = ParseField(cp, Mdate, sizeof(Mdate))) == NULL)
		return(0);
/*
 * Get time format.
 */
	if ((cp = ParseField(cp, Mtime, sizeof(Mtime))) == NULL)
		return(0);
/*
 * Get units format.
 */
	if ((cp = ParseField(cp, Munits, sizeof(Munits))) == NULL)
		return(0);
/*
 * Get minimum reading.
 */
	if ((cp = ParseField(cp, Mmin, sizeof(Mmin))) == NULL)
		return(0);
/*
 * Get maximum reading.
 */
	if ((cp = ParseField(cp, Mmax, sizeof(Mmax))) == NULL)
		return(0);
	DumpHs = 1;
	return(1);
}


/*
 * ReadAll() - read all Profile user option settings
 */

int
ReadAll()
{
	char *cp;
	short i;

	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd("DMS?", 'S')) {
			(void) GetDataLn(DumpLine, DUMPLL);
			if (strncmp(DumpLine, "?,", 2) != 0)
				return(0);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	for (cp = DumpLine; *cp; ) {
		while (*cp && *cp != ',')
			cp++;
		if ( ! *cp)
			break;
		if (*cp == ',')
			cp++;
		switch (*cp) {
		case 'B':
			(void) strcpy(Mbeep,
				(*(cp+1) == '0') ? "BEEP" : "NOBEEP");
			break;
		case 'C':
			(void) strcpy(Mcomm, "RS-232");
			break;
		case 'D':
			(void) strcpy(Mdate,
				(*(cp+1) == '0') ? " M.D.Y.  " : " D.M.Y.  ");
			break;
		case 'E':
			(void) strcpy(Mevavgs,
				(*(cp+1) == '0') ? "NOAVGS" : " AVGS ");
			break;
		case 'I':
			(void) strcpy(Minspr,
				(*(cp+1) == '0') ? "NOINSL" : " INSL ");
			break;
		case 'L':
			cp++;
			for (i = 0; LangName[i].ab; i++) {
				if (LangName[i].c == *cp)
					break;
			}
			if (LangName[i].ab)
				(void) strcpy(Mlang, LangName[i].ab);
			break;
		case 'P':
			(void) strcpy(Mpunc,
				(*(cp+1) == '0') ? "DEC PT" : "COMMA ");
			break;
		case 'R':
			(void) strcpy(Mbaud, "9600");
			break;
		case 'S':
			cp++;
			if (*cp >= '0' && *cp <= '9')
				i = *cp - '0' + 1;
			else if (*cp >= 'A' && *cp <= 'F')
				i = *cp - 'A' + 11;
			else
				break;
			(void) sprintf(Mcal, "%d", i);
			break;
		case 'T':
			(void) strcpy(Mtime,
				(*(cp+1) == '0') ? "AM/PM " : "24:00 ");
			break;
		case 'U':
			(void) strcpy(Munits,
				(*(cp+1) == '0') ? "MG/DL " : "MMOL/L");
			break;
		case 'X':
			(void) strcpy(Mlangtr, "ENGL.  ");
			break;
		}
	}
	return(1);
}


/*
 * ReadNdMark() - read Profile new-data-marker
 */

static int
ReadNdMark()
{
	char *cp;
	short i;

	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd("DM^?", '^')) {
			(void) GetDataLn(DumpLine, DUMPLL);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	return(CopyNdMark());
}


/*
 * ReadSerial() - read Profile serial number
 */

static int
ReadSerial()
{
	char *cp;
	short i;

	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd("DM@", '@')) {
			(void) GetDataLn(DumpLine, DUMPLL);
			if ((cp = strchr(DumpLine, '"')) == NULL)
				return(0);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	for (cp++, i = 0; i < (sizeof(Mserial) - 2) ; i++) {
		if (*cp == '\0' || *cp == '"')
			break;
		Mserial[i] = *cp++;
	}
	Mserial[i] = '\0';
	return(1);
}


/*
 * ReadVal() - read meter status value
 */

static int
ReadVal(c, b, bl)

#if	defined(UNIX)
	int c;				/* value code */
	char *b;			/* destination buffer */
	int bl;				/* buffer length */
#else
	char c;				/* value code */
	char *b;			/* destination buffer */
	short bl;			/* buffer length */
#endif

{
	char cmd[5], *cp; 
	(void) sprintf(cmd, "DMS%c?", c);
	*b = '\0';
	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd(cmd, c)) {
			(void) GetDataLn(DumpLine, DUMPLL);
			if ((cp = strchr(DumpLine, '"')) == NULL)
				return(0);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	CopyReply(++cp, b, bl);
	return(1);
}


/*
 * ReadVers() - read Profile software version and date
 */

static int
ReadVers()
{
	char *cp;
	short i, j;

	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd("DM?", '?')) {
			(void) GetDataLn(DumpLine, DUMPLL);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	for (cp = DumpLine, i = j = 0;
	     *cp && i < (sizeof(Mversion) - 2);
	     i++)
	{
		if ((Mversion[i] = *cp++) == ' ') {
			if (j++)
				break;
		}
	}
	Mversion[i] = '\0';
	return(1);
}


/*
 * StatusCh() - change meter status
 */
static void
StatusCh(void)
{
	int ch, ms;

	for (ms = 0;;) {
		if ( ! ms) {
			StatusMenu("Change meter status",
				"Press ESC to exit.", 1);
			ms++;
		}
		if ( ! kbhit()) {
			AsynRstBf();
			continue;
		}
		ms = 0;
		ch = getch();
		switch (ch) {

		case 'b':
		case 'B':
			if ( ! ChangeBeep())
				return;
			break;
		case 'c':
		case 'C':
			if ( ! ChangeCal())
				return;
			break;
		case 'd':
		case 'D':
			if ( ! ChangeDate())
				return;
			break;
		case 'e':
		case 'E':
			if (MtrTy != MTY_PROFILE)
				putch(BELL);
			else if ( ! ChangeEvAvgs())
				return;
			break;
		case 'i':
		case 'I':
			if (MtrTy != MTY_PROFILE)
				putch(BELL);
			else if ( ! ChangeInspr())
				return;
			break;
		case 'k':
		case 'K':
			if (MtrTy != MTY_PROFILE)
				putch(BELL);
			else if ( ! ChangeNdMark())
				return;
			break;
		case 'l':
		case 'L':
			if ( ! ChangeLang())
				return;
			break;
		case 'm':
		case 'M':
			if ( ! ChangeMcomm())
				return;
			break;
		case 'p':
		case 'P':
			if ( ! ChangePunc())
				return;
			break;
		case 'r':
		case 'R':
			if ( ! ChangeBaud())
				return;
			break;
		case 't':
		case 'T':
			if ( ! ChangeTime())
				return;
			break;
		case 'u':
		case 'U':
			if ( ! ChangeUnits())
				return;
			break;
		case 'x':
		case 'X':
		case ESC:
			return;
		default:
			if (ch == 0)
				ch = getch();
			putch(BELL);
		}
	}
}


/*
 * StatusIn() - inspect meter status
 */

static void
StatusIn(void)
{
	int ch, m;

	for (m = 0;;) {
		if ( ! m) {
			StatusMenu("Inspect meter status",
				"Press ESC to exit.", 0);
			m = 1;
		}
		if ( ! kbhit()) {
			AsynRstBf();
			continue;
		}
		m = 0;
		ch = getch();
		switch (ch) {

		case 'a':
		case 'A':
			if (MtrTy != MTY_PROFILE) {
				putch(BELL);
				break;
			}
			if ( ! ReadAll())
				return;
			break;
		case 'b':
		case 'B':
			if ( ! ReadVal('B', Mbeep, sizeof(Mbeep)))
				return;
			break;
		case 'c':
		case 'C':
			if ( ! ReadVal('S', Mcal, sizeof(Mcal)))
				return;
			break;
		case 'd':
		case 'D':
			if ( ! ReadVal('D', Mdate, sizeof(Mdate)))
				return;
			break;
		case 'e':
		case 'E':
			if (MtrTy != MTY_PROFILE)
				putch(BELL);
			else if ( ! ReadVal('E', Mevavgs, sizeof(Mevavgs)))
				return;
			break;
		case 'i':
		case 'I':
			if (MtrTy != MTY_PROFILE)
				putch(BELL);
			else if ( ! ReadVal('I', Minspr, sizeof(Minspr)))
				return;
			break;
		case 'k':
		case 'K':
			if (MtrTy != MTY_PROFILE)
				putch(BELL);
			else if ( ! ReadNdMark())
				return;
			break;
		case 'l':
		case 'L':
			if ( ! ReadVal('L', Mlang, sizeof(Mlang)))
				return;
			break;
		case 'm':
		case 'M':
			if ( ! ReadVal('C', Mcomm, sizeof(Mcomm)))
				return;
			break;
		case 'p':
		case 'P':
			if ( ! ReadVal('P', Mpunc, sizeof(Mpunc)))
				return;
			break;
		case 'r':
		case 'R':
			if ( ! ReadVal('R', Mbaud, sizeof(Mbaud)))
				return;
			break;
		case 's':
		case 'S':
			if (MtrTy != MTY_PROFILE) {
				putch(BELL);
				break;
			}
			if ( ! ReadSerial())
				return;
			break;
		case 't':
		case 'T':
			if ( ! ReadVal('T', Mtime, sizeof(Mtime)))
				return;
			break;
		case 'u':
		case 'U':
			if ( ! ReadVal('U', Munits, sizeof(Munits)))
				return;
			break;
		case 'v':
		case 'V':
			if (MtrTy != MTY_PROFILE) {
				putch(BELL);
				break;
			}
			if ( ! ReadVers())
				return;
			break;
		case 'x':
		case 'X':
		case ESC:
			return;
		default:
			if (ch == 0)
				ch = getch();
			putch(BELL);
		}
	}
}


/*
 * StatusMenu() - display status menu
 */

static void
StatusMenu(ttl, bot, ty)
	char *ttl;			/* menu title */
	char *bot;			/* text for bottom line */
	int ty;				/* type: 0 = inspect, 1 = change */
{
	short ln, lx;

	clrscr();
	gotoxy(COL, 2);
	(void) cputs(ttl);
	PromptMsg(bot);
	ln = 4;
	if (MtrTy == MTY_PROFILE && ty == 0) {
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("A - All Profile option settings");
	}
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("B - Beeper status: %s", Mbeep);
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("C - strip lot Calibration code: %s", Mcal);
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("D - Date format: %s", Mdate);
	if (MtrTy == MTY_PROFILE) {
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("E - event averages: %s", Mevavgs);
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("I - Profile Insulin prompt: %s", Minspr);
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("K - Profile new-data-marKer: %s", Mndmark);
	}
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	for (lx = 0; LangName[lx].ab; lx++) {
		if (strcmpi(Mlang, LangName[lx].ab) == 0)
			break;
	}
	cprintf("L - message and prompt Language: %s", LangName[lx].nm);
	if (MtrTy == MTY_PROFILE) {
		for (lx = 0; LangName[lx].ab; lx++) {
			if (strcmpi(Mlangtr, LangName[lx].ab) == 0)
				break;
		}
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("    Profile language translation: %s",
			LangName[lx].nm);
	}
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("M - communications Mode: %s", Mcomm);
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("P - mmol/L Punctuation: %s", Mpunc);
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("R - baud Rate: %s", Mbaud);
	if (ty == 0) {
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("%s Serial number: %s",
			(MtrTy == MTY_PROFILE) ? "S -" : "   ",
			Mserial);
	}
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("T - Time display format: %s", Mtime);
	ClearRow(ln, COL);
	gotoxy(COL, ln++);
	cprintf("U - glucose Units: %s", Munits);
	if (MtrTy == MTY_PROFILE && ty == 0) {
		ClearRow(ln, COL);
		gotoxy(COL, ln++);
		cprintf("V - Profile software version and date: %s",
			Mversion);
	}
	ClearRow(ln, COL);
	gotoxy(COL, ln);
	(void) cputs("X - eXit");
	(void) DispMtrTy();
}


/*
 * StatusMtr() - inspect/change meter status
 */

void
StatusMtr(void)
{
	int ch;

	DispMenu(StatusType, NULL);
	for (;;) {
		if ( !kbhit()) {
			AsynRstBf();
			continue;
		}
		ch = getch();
		switch(ch) {

		case 'c':
		case 'C':
			StatusCh();
			break;
		case 'i':
		case 'I':
			StatusIn();
			break;
		case 'x':
		case 'X':
		case ESC:
			return;
		default:
			if (ch == 0)
				ch = getch();
			putch(BELL);
		}
		DispMenu(StatusType, NULL);
	}
}


/*
 * WriteVal() - write meter status value
 */

int
WriteVal(c, r, rl)
	char *c;			/* command */
	char *r;			/* result */

#if	defined(UNIX)
	int rl;				/* result buffer length */
#else
	short rl;			/* result buffer length */
#endif

{
	char cmd[6], *cp;

	(void) sprintf(cmd, "DMS%c%c", *c, *(c+1));
	*r = '\0';
	for (;;) {
		if (WaitRdy(1) == 0)
			return(0);
		if (WaitCmd(cmd, *c)) {
			(void) GetDataLn(DumpLine, DUMPLL);
			if ((cp = strchr(DumpLine, '"')) == NULL)
				return(0);
			break;
		}
		DispMenu(CmdFail,
			"Press ESC to exit; any other key to retry.");
		if ((char)WaitAnyKey() == ESC)
			return(0);
	}
	CopyReply(++cp, r, rl);
	return(1);
}
