/*
 * grph.c - graph support
 */

/*
 * Copyright 1993, 1994, 1995, 1996 Victor A. Abell, Lafayette, Indiana 47906.
 * All rights reserved.
 *
 * Written by Victor A. Abell.
 *
 * Permission is granted to anyone to use this software for any purpose on
 * any computer system, and to alter it and redistribute it freely, subject
 * to the following restrictions:
 *
 * 1. Victor A. Abell is not responsible for any consequences of the use of
 * this software.
 *
 * 2. The origin of this software must not be misrepresented, either by
 *    explicit claim or by omission.  Credit to Victor A. Abell must
 *    appear in documentation and sources.
 *
 * 3. Altered versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 *
 * 4. This notice may not be removed or altered.
 */

#if	!defined(lint)

# if	defined(_BCC)
#pragma warn -use
# endif

static char copyright[] =
"@(#) Copyright 1993, 1994, 1995, 1996 Victor A. Abell.\nAll rights reserved.\n";
#endif

#include "touch2.h"
#include <ctype.h>
#include <math.h>

#define	FIELDLN	16			/* dump line field length */
#define GPFX	32			/* graph prefix column count */
#define STARTPX	4			/* starting VGA y pixel */

struct extravals {
	double rval[2];			/* reading values */
	short stat[2];			/* status: 0 = no reading available
					 *	   1 = reading available */
	short ec[2];			/* event code */
	short units[2];			/* units: 0 = mg/dL, 1 = mmol/L */
};

static struct extravals Bolus;		/* Bolus Insulin reading */
short Bt;				/* beginning time of RangeInUse */
static struct extravals Carb;		/* carbohydrate reading */
char Date[FIELDLN];			/* dump line date */
char DateSave[FIELDLN];			/* saved dump line date */
char Dow[FIELDLN];			/* dump line day of week */
char DowSave[FIELDLN];			/* saved dump line day of week */
short Et;				/* ending time of RangeInUse */
short Event;				/* dump line event value (0 = none) */
short EventSave;			/* save dump line event value */
struct evcode EventCode[] = {		/* Profile event codes */
	{ "  ",	"None" },		/* 0 */
	{ "FA",	"Fasting" },		/* 1 */
	{ "PB",	"Pre Breakfast" },	/* 2 */
	{ "AB",	"After Breakfast" },	/* 3 */
	{ "PN",	"Pre Noon Meal" },	/* 4 */
	{ "AN",	"After Noon Meal" },	/* 5 */
	{ "PD",	"Pre Dinner" },		/* 6 */
	{ "AD",	"After Dinner" },	/* 7 */
	{ "DF",	"Different Food" },	/* 8 */
	{ "BT",	"Bedtime" },		/* 9 */
	{ "DN",	"During Night" },	/* 10 */
	{ "PE",	"Pre Exercise" },	/* 11 */
	{ "AE",	"After Exercise" },	/* 12 */
	{ "IL",	"Illness" },		/* 13 */
	{ "HY",	"Hypoglycemia" },	/* 14 */
	{ "OT",	"Other" }		/* 15 */
};
short Eventfilt = 0;			/* event filter (0 = none) */
double Gmaxl;				/* graph maximum line */
double Gminl;				/* graph minimum line */
static char *InsType[] = {		/* Profile Insulin types */
	"Reg.",				/* 0 */
	"NPH",				/* 1 */
	"Lente",			/* 2 */
	"ULen.",			/* 3 */
	"70/30",			/* 4 */
	"50/50",			/* 5 */
	"Mix",				/* 6 */
	"Other",			/* 7 */
	"Bolus",			/* 8 */
	"Carb.",			/* 9 */
	"80/20",			/* 10 */
	"60/40"				/* 11 */
};
short Lpp = LPP;			/* lines per page */
int Maxx;				/* maximum VGA x coordinate */
int Maxy;				/* maximum VGA y coordinate */
static struct extravals Other;		/* first other Insulin reading */
short PDLStat = 0;			/* saved dump line status */
double Rval;				/* dump line reading value */
double RvalSave;			/* saved dump line reading value */
char *TDumpLp[DUMPNL];			/* temporary dump line pointers */
char Time[FIELDLN];			/* dump line time */
short TimeB;				/* time converted to binary */
short TimeBSave;			/* saved time converted to binary */
char TimeSave[FIELDLN];			/* saved dump line time */
int TxtHt;				/* VGA text height */
int TxtWid;				/* VGA text width */
char Units[FIELDLN];			/* dump line units */

char *MeasName[] = { "Regular", "Check Solution (C)", "Check Strip (!)",
		     "Meter Error (*)" };

static int EntGraph(void);
static int CheckRange(void);
static int GetPLogV(int s);
static int TestDecPt(char *cp);


/*
 * CheckRange() - check for time within range
 */

static int
CheckRange(void)
{
	if (Bt < Et) {
		if (TimeB >= Bt && TimeB < Et)
			return(1);
		return(0);
	}
	if (TimeB >= Bt || TimeB < Et)
		return(1);
	return(0);
}


/*
 * DrawGraph() - draw a graph of meter memory values
 */

void
DrawGraph(ty)
	int ty;				/* type: 0 = screen, 1 = file */
{

#if	defined(UNIX)
	int i;
#else
	short i;
#endif

	short pvct, pvmx, pvx, pvx2, pvx3;
	char ch, *cp1, *cp2, ec[3], gttl[2][82], hdr[5][72], ln[82], pr[80];
	short dtla, dtlu, gp, ska, sku, tmla, tmlu;
	short err, gmn, gmx, j, k, lpp, lps, mmol, n[4], nl, pc, pps, prow, row;
	double fn, dj, dk, iv, max[4], min[4], mn, mx, sumx[4], sumxx[4];
	char pca[PRTRCTLLN+1], pcb[PRTRCTLLN+1];
	int hth, htw, len, pcal, pcbl;

#if	defined(UNIX)
	int g, gt, pcol;
#else
	short g, gt, pcol;
#endif

/*
 * If graphing to screen, enter high resolution VGA mode.
 */
	if ( !ty) {
		if (EntGraph() != 0) {

VGA_needed:

		    (void) WarnMsg(10, 20,
			"The graph function requires high resolution VGA.",
			12, 20,
			"This display does not support that mode.", 0);
		    return;
		}
		Maxx = getmaxx();
		Maxy = getmaxy();
		TxtHt = textheight("H");
		TxtWid = textwidth("M");
	}
/*
 * Miscellaneous setup.
 */
	for (j = 0; j < 4; j++) {
		max[j] = 0.0;
		min[j] = 9999.0;
		n[j] = 0;
		sumx[j] = sumxx[j] = 0.0;
	}
	if (!ty) {
		hth = (TxtHt + 1) / 2;
		htw = TxtWid / 2;
		pps = Maxy - (2 * TxtHt) - 4;
		lps = pps / (TxtHt + 1);
	} else {
		pps = STARTPX+1;
		TxtHt = -1;
	}
	if (RangeInUse > 0) {
		Bt = TmRange[RangeInUse - 1].bt;
		Et = TmRange[RangeInUse - 1].et;
	}
	sku = SkipUnt;
	if (SkipAft) {
		dtla = strlen(SkipAftDt);
		tmla = strlen(SkipAftTm);
	}
	if (SkipUnt) {
		dtlu = strlen(SkipUntDt);
		tmlu = strlen(SkipUntTm);
	}
	gp = GPFX;
	if (MtrTy != MTY_PROFILE)
		gp--;
/*
 * Accumulate statistics values.
 */
	for (err = mmol = pvmx = ska = 0, i = nl = DumpHs; i < DumpLc; i++) {
		if ((j = ParseDumpLn(DumpLp[i], 0, 0)) == 0) {
		    err = 1;
		    closegraph();
		    Vmode=0;
		    if ((char)WarnMsg(10, 34, "Bad dump line:", 12,
			(short)(((Vc.screenwidth - strlen(DumpLp[i]))/2)+1),
			DumpLp[i], 1)
		    == ESC) {
graph_exit:
			if ( ! ty) {
			    if (Vmode) {
				closegraph();
				Vmode = 0;
			    }
			}
		    	return;
		    }
		    if (EntGraph() != 0)
			goto VGA_needed;
		    continue;
		}
		if (j == 2)
			mmol = 1;
		if (j > 3)
			continue;
		if (Rtype != RDREG
		&&  Rtype != RDSOL
		&&  Rtype != RDSTRIP
		&&  Rtype != RDMTRERR
		)
			continue;
	/*
	 * Apply filters.
	 */
		if (ska)
			continue;
		if (sku) {
		    if (strncmp(Date, SkipUntDt, dtlu) != 0
		    ||  strncmp(Time, SkipUntTm, tmlu) != 0)
			continue;
		    sku = 0;
		}
		if (SkipAft) {
		    if (strncmp(Date, SkipAftDt, dtla) == 0
		    &&  strncmp(Time, SkipAftTm, tmla) == 0)
			ska = 1;
		}
		if (RangeInUse > 0 && CheckRange() == 0)
			continue;
		if (Eventfilt && (Event != Eventfilt))
			continue;
		if (Event > 0 && IgnEvt[Event - 1])
			continue;
		if (EEvtGrp) {
		    struct evtgrpe *eg;

		    for (eg = EEvtGrp->grp; eg; eg = eg->next) {
			if (eg->grp == Event)
			    break;
		    }
		    if ( ! eg)
			continue;
		}
	/*
	 * Graph this record.
	 */
		TDumpLp[nl++] = DumpLp[i];
		sumx[Rtype] += Rval;
		sumxx[Rtype] += Rval * Rval;
		n[Rtype]++;
		if (max[Rtype] < Rval)
			max[Rtype] = Rval;
		if (min[Rtype] > Rval)
			min[Rtype] = Rval;
		if (DumpMtrTy == MTY_PROFILE) {
			if ((j = GetPLogV(0)) > 0 && j > pvmx)
				pvmx = j;
		}
	}
	if (err)
		goto graph_exit;
/*
 * Form statistics lines.
 */
	(void) sprintf(&hdr[0][0], "%-11.11s %-16s %7s %6s %8s %6s %6s",
	    (MtrTy == MTY_UNKNOWN) ? ""
				   : (MtrTy == MTY_PROFILE) ? "Profile"
							    : "One Touch 2",
	    "", "Number", "Mean", "Std Dev", "Min", "Max");
	for (j = 0; j < 4; j++) {
		if ( ! n[j]) {
			hdr[j+1][0] = '\0';
			continue;
		}
		fn = (float)n[j];
		(void) sprintf(&hdr[j+1][0],
			"          %-18s %7d %6.1f %8.2f %6.1f %6.1f",
			MeasName[j], n[j], sumx[j]/fn,
			sqrt(sumxx[j]/fn - (sumx[j]/fn * sumx[j]/fn)),
			min[j], max[j]);
	}
/*
 * See if there are additional Profile log values, Carbohydrate and Insulin
 * readings -- to display.  If there are, adjust the graph prefix length.
 */
	if (pvmx) {
		pvx = gp - 2;
		if (pvmx > 2)
			pvmx = 2;
		gp += (11 * pvmx);
	}
/*
 * Establish graph parameters.
 */
	if ( ! Lineval) {
		if (mmol) {
			Gmaxl = DEFMMMAX;
			Gminl = DEFMMMIN;
		} else {
			Gmaxl = DEFMGMAX;
			Gminl = DEFMGMIN;
		}
	}
	mn = (Gminl < min[0]) ? Gminl : min[0];
	mx = (Gmaxl > max[0]) ? Gmaxl : max[0];
	dk = (double)(((Vc.screenwidth > 80) ? 80 : Vc.screenwidth) - gp - 2);
	if ((iv = (mx - mn) / dk) < 0.1)
		iv = 0.1;
	gmn = (int)((Gminl - mn) / iv) + gp;
	gmx = (int)((Gmaxl - mn) / iv) + gp;
	(void) sprintf(&gttl[0][0], "%.3f %s per column", iv,
		mmol ? "mmol/L" : "mg/dL");
	for (j = strlen(&gttl[0][0]); j < gp; j++)
		gttl[0][j] = ' ';
 	for (j = 0; j < gp; j++)
		gttl[1][j] = ' ';
	cp1 = &gttl[0][gp-4];
	cp2 = &gttl[1][gp];
	for (dj = mn; dj < mx; ) {
		(void) sprintf(cp1, "%5.1f", dj);
		cp1 += 5;
		*cp2++ = '+';
		*cp2 = '\0';
		dj += iv;
		for (k = 0; k < 5 && dj <= mx; k++) {
			if (k < 1) {
				*cp1++ = ' ';
				*cp1 = '\0';
			}
			*cp2++ = '-';
			*cp2 = '\0';
			dj += iv;
		}
	}
/*
 * If drawing graph to file, create printer control strings.
 */
	if (ty) {
		if (AftGraph)
		    pcal = CvtPrtrStr(AftGraph, pca, sizeof(pca));
		if (BefGraph) {
		    if ((pcbl = CvtPrtrStr(BefGraph, pcb, sizeof(pcb))) > 0)
			(void) fwrite((void *)pcb, (size_t)pcbl, 1, Graphfs);
		}
		lpp = Lpp;
		pc = 0;
	}
/*
 * Refill screen.
 */
	for (j = pcol = 0;;) {
		if ( ! ty) {
			pcol = 0;
			cleardevice();
			(void) sprintf(pr,
				"(%d of %d) Press ESC or X to exit; Page Up/Down; Arrow Up/Down.",
				(j < 9) ? 1 : j - 9 + 1, nl - DumpHs);
			PromptMsg(pr);
		}
		for (prow = row = STARTPX, k = j;
		     row < pps && k < nl+9-DumpHs;
		     k++, row += (TxtHt + 1))
		{
			if ( ! ty)
				moveto(0, row);
			switch (k) {
			case 0:
				if ( ! ty)
					outtext(Exttl);
				break;

			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				if ( ! ty)
					outtext(&hdr[k-1][0]);
				break;
			case 6:
				break;
			case 7:
			case 8:
				if ( ! ty)
					outtext(&gttl[k-7][0]);
				break;
			default:
				(void) ParseDumpLn(TDumpLp[k-9+DumpHs], 1, 0);
				if (Rtype == RDREG)
				    g = (int)((Rval - mn) / iv) + gp;
				if (MtrTy == MTY_PROFILE)
					(void) strcpy(ec, EventCode[Event].ab);
				else {
				    if (Event < 1)
					(void) strcpy(ec, " ");
				    else
					(void) sprintf(ec, "%x", Event);
				}
				switch (Rtype) {
				case RDSOL:
				    ch = 'C'; break;
				case RDSTRIP:
				    ch = '!'; break;
				case RDMTRERR:
				    ch = '*'; break;
				default:
				    ch = ' ';
				}
				(void) sprintf(ln,
				    "%-3.3s %-8.8s %-8.8s %s%c%5.1f",
				    Dow, Date, Time, ec, ch, Rval);
				if (pvmx) {
				    (void) GetPLogV(1);
				    for (pvct = pvx3 = 0, pvx2 = pvx;
					 pvx3 < 2;
					 pvx3++)
				    {
					if (Carb.stat[pvx3]) {
					    (void) sprintf(&ln[pvx],
						" %4d Carb.",
						(int)Carb.rval[pvx3]);
					    pvx2 += 11;
					    pvct++;
					}
				    }
				    for (pvx3 = 0; pvct < 2 && pvx3 < 2; pvx3++)
				    {
					if (Bolus.stat[pvx3]) {
					    (void) sprintf(&ln[pvx2],
						" %4.1f Bolus",
						Bolus.rval[pvx3]);
					    pvx2 += 11;
					    pvct++;
					}
				    }
				    for (pvx3 = 0; pvct < 2 && pvx3 < 2; pvx3++)
				    {
					if (Other.stat[pvx3]) {
					    (void) sprintf(&ln[pvx2],
						" %4d %-5.5s",
						(int)Other.rval[pvx3],
						InsType[Other.ec[pvx3]]);
					    pvx2 += 11;
					    pvct++;
					}
				    }
				    while (pvx2 < gp)
					ln[pvx2++] = ' ';
				    ln[pvx2] = '\0';
				}
				if (ty) {
				    if (lpp >= Lpp) {
					pc++;
					if (PcDisp) {
					    (void) fprintf(Graphfs,
						"%s\nPage %2d:  %s\n",
						pc > 1 ? "\f" : "",
						pc, Exttl);
					} else {
					    (void) fprintf(Graphfs,
						"%s\n          %s\n",
						pc > 1 ? "\f" : "",
						Exttl);
					}
					(void) fprintf(Graphfs,
					    "\n%s\n%s\n%s\n%s\n%s\n\n%s\n%s\n",
					    &hdr[0][0],
					    &hdr[1][0],
					    &hdr[2][0],
					    &hdr[3][0],
					    &hdr[4][0],
					    &gttl[0][0],
					    &gttl[1][0]);
					lpp = HDRLPP;
				    }
				    if (Rtype != RDREG) {
					gt = gmx;
					g = gp-2;
				    } else
				        gt = (g > gmx) ? g : gmx;
				    ln[gt+1] = '\0';
				    for (; gt >= gp-2; gt--) {
					if (gt == gmn || gt == gmx) {
					    ln[gt] = (gt <= g) ? IntCh[0]
							       : LineCh[0];
					} else if (gt >= gp && gt <= g)
					    ln[gt] = BarCh[0];
					else
					    ln[gt] = ' ';
				    }
				    (void) fprintf(Graphfs, "%s\n", ln);
				    lpp++;
				} else {
					outtext(ln);
					if (gmn)
						outtextxy(gmn * 8, row,
							LineCh);
					if (gmx)
						outtextxy(gmx * 8, row,
							LineCh);
					if (Rtype != RDREG)
						break;
					if (pcol) {
						moveto((pcol * TxtWid) + htw,
							prow + hth);
						lineto((g * TxtWid) + htw,
							row + hth);
					}
					pcol = g;
					prow = row;
				}
			}
		}
	/*
	 * See if done graphing to file.
	 */
		if (ty) {
			if (k >= nl+9-DumpHs) {
				if (pcal > 0) {
					(void) fwrite((void *)pca,
						(size_t)pcal, 1, Graphfs);
				}
				(void) fclose(Graphfs);
				Graphfs = NULL;
				return;
			}
			j = k;
			continue;
		}
	/*
	 * Wait for keyboard input.
	 */
		for (k = 1; k;) {
			switch ((char)WaitAnyKey()) {
			case ESC:
			case 'x':
			case 'X':
				goto graph_exit;
			case PGDN:
				if ((j + lps) < (nl+9-DumpHs)) {
					j += lps;
					k = 0;
				} else
					putch(BELL);
				break;
			case PGUP:
				if (j < lps)
					j = 0;
				else
					j = j - lps;
				k = 0;
				break;
			case UARW:
				if (j) {
					j--;
					k = 0;
				} else
					putch(BELL);
				break;
			case DARW:
				if (j < (nl+9-DumpHs-1)) {
					j++;
					k = 0;
				} else
					putch(BELL);
				break;
			default:
				putch(BELL);
			}
		}
	}
}


/*
 * EntGraph() - enter graphics mode
 */

static int
EntGraph()
{
	int gdrv, gmode;

	gdrv = VGA;
	gmode = VGAMED;
	registerbgidriver(EGAVGA_driver);
	initgraph(&gdrv, &gmode, "");
	if (graphresult() != 0)
		return(1);
	setbkcolor((int)(BkClrx & 15));
	setcolor((int)(TxtClrx & 15));
	Vmode = 1;
	return(0);
}


/*
 * GetPLogV() - get Profile log values, Insulin and Carbohydrate readings,
 *		associated with the dump record currently parsed
 *
 * return: columns (1 - 4) required for readings (0 = no readings)
 */

static int
GetPLogV(s)
	int s;				/* seconds flag for ParseDumpLn() */
{
	int i, j, k;

	SavePDL();
	for (i = 0; i < 2; i++)
		Bolus.stat[i] = Carb.stat[i] = Other.stat[i] = 0;
	for (i = DumpHs; i < DumpLc; i++) {
	    if ((j = ParseDumpLn(DumpLp[i], s, 1)) <= 0)
		continue;
	    if (j > 2)
		continue;
	    j--;
	    if (Rtype != RDBOLI && Rtype != RDOTHI && Rtype != RDCARB)
		continue;
	    switch (Rtype) {
	    case RDBOLI:
		if ( ! Bolus.stat[0])
		    k = 0;
		else if (Bolus.stat[1])
			break;
		else
		    k = 1;
		Bolus.ec[k] = Event;
		Bolus.rval[k] = Rval;
		Bolus.stat[k] = 1;
		Bolus.units[k] = j;
		break;
	    case RDCARB:
		if ( ! Carb.stat[0])
		    k = 0;
		else if (Carb.stat[1])
			break;
		else
		    k = 1;
		Carb.ec[k] = Event;
		Carb.rval[k] = Rval;
		Carb.stat[k] = 1;
		Carb.units[k] = j;
		break;
	    case RDOTHI:
		if ( ! Other.stat[0])
		    k = 0;
		else if (Other.stat[1])
			break;
		else
		    k = 1;
		Other.ec[k] = Event;
		Other.rval[k] = Rval;
		Other.stat[k] = 1;
		Other.units[k] = j;
	    }
	    if ((Bolus.stat[0] + Bolus.stat[1] +
	         Carb.stat[0]  + Carb.stat[1]  +
	         Other.stat[0] + Other.stat[1])
	    > 1)
		break;
	}
	RestorePDL();
	return((int)(Bolus.stat[0] + Bolus.stat[1] +
		     Carb.stat[0]  + Carb.stat[1]  +
		     Other.stat[0] + Other.stat[1]));
}


/*
 * ParseDumpLn() - parse dump line
 *
 * return: 0 = parse error or mismatched saved date or time
 *	   1 = normal mg/dL reading
 *	   2 = normal mmol/L reading
 *	   3 = meter error reading
 *	   4 = HIGH reading
 *	   5 = HIGH check strip reading
 */

int
ParseDumpLn(dl, s, m)
	char *dl;			/* dump line pointer */

#if	defined(UNIX)
	int s;				/* seconds flag */
	int m;				/* match saved date and time if 1 */
#else
	short s;			/* seconds flag */
	short m;			/* match saved date and time if 1 */
#endif

{
	char *cp, *cp1, msg[128], rc;
	int t;
	short rv;
/*
 * Parse day of week, date, time and reading (units).
 *
 * Shorten the time by eliminating the :00 seconds.
 *
 * Do date and time matches, as requested.
 */
	if ((cp = ParseField(dl, Dow, sizeof(Dow))) == NULL
	||  (m && strcmpi(Dow, DowSave) != 0))
		return(0);
	if ((cp = ParseField(cp, Date, sizeof(Date))) == NULL
	||  (m && strcmp(Date, DateSave) != 0))
		return(0);
	if ((cp = ParseField(cp, Time, sizeof(Time))) == NULL)
		return(0);
	if (s) {
		if (strncmp(&Time[5], ":00", 3) == 0) {
			for (cp1 = &Time[5];; cp1++) {
				if ((*cp1 = *(cp1+3)) == '\0')
					break;
			}
		}
	}
	if (m && strcmp(Time, TimeSave) != 0)
		return(0);
	if ((cp = ParseField(cp, Units, sizeof(Units))) == NULL)
		return(0);
/*
 * Convert the last two characters of the day of week to lower case.
 */
	if (Dow[1] && isascii(Dow[1]) && isupper(Dow[1]))
		Dow[1] = tolower(Dow[1]);
	if (Dow[2] && isascii(Dow[2]) && isupper(Dow[2]))
		Dow[2] = tolower(Dow[2]);
/*
 * Get event number.
 */
	if (*cp++ != ',')
		return(0);
	while (*cp && *cp == ' ')
		cp++;
	if ( ! *cp)
		return(0);
	if ((Event = (short)atoi(cp)) < 0 || Event > 15)
		return(0);
/*
 * If a time range specification is in use, convert the time
 * character string to binary.
 */
	if (RangeInUse > 0) {
		cp1 = Time;
		if ((t = CvtTm(&cp1, msg)) < 0)
			return(0);
		TimeB = (short)t;
	}
/*
 * Get reading type and convert the value.
 */
	cp = Units;
	cp1 = cp + 1;
	rv = 1;
	switch (*cp) {
		case ' ':
			if (strcmpi(cp, " HIGH ") == 0) {
				Rtype = RtypeB4Err = RDHIGH;
				return(4);
			}
			if (*cp1 != ' ')
				return(0);
			Rtype = RtypeB4Err = RDREG;
			break;
		case '!':
			if (*cp1++ != ' ')
				return(0);
			if (strncmp(cp1, "HIGH", 4) == 0) {
				Rtype = RtypeB4Err = RDCKHI;
				return(5);
			}
			if (TestDecPt(cp1))
				rv = 2;
			Rtype = RtypeB4Err = RDSTRIP;
			break;
		case 'C':
		case 'K':			/* SVENS || DEUTS */
			if (*cp1++ != ' ')
				return(0);
			if (TestDecPt(cp1))
				rv = 2;
			Rtype = RtypeB4Err = RDSOL;
			break;
		case 'I':
			if (*cp1++ != ' ')
				return(0);
			if (TestDecPt(cp1))
				Rtype = RtypeB4Err = RDBOLI;
			else {
				if (*cp1 && (*cp1 == '0' || *cp1 == '1'))
					Rtype = RtypeB4Err = RDCARB;
				else
					Rtype = RtypeB4Err = RDOTHI;
			}
			if (MtrTy == MTY_UNKNOWN)
				MtrTy = MTY_PROFILE;
			break;
		case 'M':
			if (*cp1 != 'M')
				return(0);
			rv = 2;
			Rtype = RtypeB4Err = RDREG;
			break;
		default:
			return(0);
	}
	cp += 2;
/*
 * Parse value.
 */
	if ( ! Atof(cp, &Rval, NULL, &rc)) {
		if (rc == '?') {
			Rtype = RDMTRERR;
			return(3);
		}
		Rval = 0.0;
		return(0);
	}
	return(rv);
}


/*
 * RestorePDL() - restore saved parsed dump line
 */

void
RestorePDL()
{
	if (!PDLStat) {
	    (void) fprintf(stderr,
		"%s: attempt to restore an unsaved parsed dump line\n", Pn);
	    exit(1);
	}
	PDLStat = 0;
	(void) strncpy(Date, DateSave, sizeof(Date));
	(void) strncpy(Dow, DowSave, sizeof(Dow));
	Event = EventSave;
	TimeB = TimeBSave;
	(void) strncpy(Time, TimeSave, sizeof(Time));
	Rtype = RtypeSave;
	Rval = RvalSave;
}


/*
 * SavePDL() - save parsed dump line
 */

void
SavePDL()
{
	if (PDLStat) {
	    (void) fprintf(stderr,
		"%s: attempt to save parsed dump line more than once\n", Pn);
	    exit(1);
	}
	PDLStat = 1;
	(void) strncpy(DateSave, Date, sizeof(Date));
	(void) strncpy(DowSave, Dow, sizeof(Dow));
	EventSave = Event;
	TimeBSave = TimeB;
	(void) strncpy(TimeSave, Time, sizeof(Time));
	RtypeSave = Rtype;
	RvalSave = Rval;
}


/*
 * TestDecPt() - test range value for decimal point
 */

static int
TestDecPt(cp)
	char *cp;			/* 3rd digit of reading */
{
	short i;

	for (i = 0; i < 2; i++) {
		if (*cp && (*cp == ' ' || (*cp >= '0' && *cp <= '9')))
			cp++;
		else
			return(0);
	}
	if (*cp && *cp == '.')
		return(1);
	return(0);
}
